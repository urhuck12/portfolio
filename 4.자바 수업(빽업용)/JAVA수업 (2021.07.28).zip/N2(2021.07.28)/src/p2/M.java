package p2;
public class M {
	public static void main(String[] args) {
		MPlay mp = new MPlay();
		mp.run();
	}
}
