package p2;
import java.util.Scanner;

public class MPlay {
	

	Scanner sc = new Scanner(System.in);			
	String cmd = "";			

public void run() { //기본 프로그램
	
	boolean isNotEnd = true;			
	while(isNotEnd) {
		dispGuide();
		cmd = sc.next(); // sc.next() 하는 순간 콘솔 창에서 우리의 입력을 기다리는 상태가 됨.		
		switch (cmd) {		
		case "1":		
			proc1();	
			break;	
		case "2":		
			proc2();	
			break;	
		case "3":		
			proc3();	
			break;	
		case "exit":		
			isNotEnd = false;	
			break;
		default:
			System.out.println("없는 명령문 입니다");
			break;
		}		
		}	
		System.out.print("프로그램 종료");	
	}

void proc1() { //1번 프로그램 분할 
	boolean isNotEnd = true;
	while(isNotEnd) {
		dispGuide1();
		cmd = sc.next(); 
		switch (cmd) {
		case "1":
			proc1proc1();
			break;
		case "2":
			proc1proc2();
			break;
		case "e":
			isNotEnd = false;
			break;
		default:
			System.out.println("없는 명령입니다.");
			break;
		}
	}
	System.out.print("1번 프로그램 종료");	
	}
void proc1proc1() { // 1번의1
	System.out.println("1-1 프로그램");
	}
void proc1proc2() {// 1번의2
	System.out.println("1-2 프로그램");
	}


void proc2() { //2번 분할
	boolean isNotEnd = true;
	while(isNotEnd) {
		dispGuide2();
		cmd = sc.next(); 
		switch (cmd) {
		case "1":
			proc2proc1();
			break;
		case "2":
			proc2proc2();
			break;
		case "e":
			isNotEnd = false;
			break;
		default:
			System.out.println("없는 명령입니다.");
			break;
		}
	}
	
	System.out.print("2번 프로그램 종료");	
}
void proc2proc1() { // 2번의1
	System.out.println("2-1 프로그램");
	}
void proc2proc2() {// 2번의2
	System.out.println("2-2 프로그램");
	}


 void proc3() { //  3번 분할
		boolean isNotEnd = true;
		while(isNotEnd) {
			dispGuide3();
			cmd = sc.next(); 
			switch (cmd) {
			case "1":
				proc3proc1();
				break;
			case "2":
				proc3proc2();
				break;
			case "e":
				isNotEnd = false;
				break;
			default:
				System.out.println("없는 명령입니다.");
				break;
			}
		}	
		System.out.print("3번 프로그램 종료");	
}
 
void proc3proc1() { // 3번의1
	System.out.println("3-1 프로그램");
}
void proc3proc2() {// 3번의1
	System.out.println("3-2 프로그램");
}
void dispGuide() {//기본
	System.out.print(		
			"\n*******************\n"+
			"1. 1번 프로그램 \n"+
			"2. 2번 프로그램 \n"+
			"3. 3번 프로그램 \n"+
			"e. 프로그램 종료 \n"+
			"*******************\n"+
			"명령:\n" );
}

void dispGuide1() {//1번
	System.out.print(		
			"\n*******************\n"+
			"1. 1번 프로그램 \n"+
			"2. 2번 프로그램 \n"+
			"3. 3번 프로그램 \n"+
			"e. 프로그램 종료 \n"+
			"*******************\n"+
			"명령:\n" );
}

void dispGuide2() {//2번
	System.out.print(		
			"\n*******************\n"+
			"1. 1번 프로그램 \n"+
			"2. 2번 프로그램 \n"+
			"3. 3번 프로그램 \n"+
			"e. 프로그램 종료 \n"+
			"*******************\n"+
			"명령:\n" );
}

 void dispGuide3() {//3번
	System.out.print(		
			"\n*******************\n"+
			"1. 1번 프로그램 \n"+
			"2. 2번 프로그램 \n"+
			"3. 3번 프로그램 \n"+
			"e. 프로그램 종료 \n"+
			"*******************\n"+
			"명령:\n" );
}
}	



