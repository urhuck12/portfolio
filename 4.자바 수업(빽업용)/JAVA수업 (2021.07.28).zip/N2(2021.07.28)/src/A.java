



public class A {
public static void main(String[] args) {
	Mplay mp = new Mplay();
	mp.run();
}
}

	
	

