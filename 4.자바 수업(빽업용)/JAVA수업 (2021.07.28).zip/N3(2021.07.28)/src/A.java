import C.Cplay;

public class A {
public static void main(String[] args) {
	Cplay mp = new Cplay();
	mp.run();
}
}

	
	

