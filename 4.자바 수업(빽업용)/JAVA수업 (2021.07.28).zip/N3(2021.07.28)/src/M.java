import java.util.Scanner;

public class M {
	public static void main(String[] args) {
		System.out.println("로켓 발사 프로그램 실행...");			
		System.out.println("카운트할 정수 입력 : ");			
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);			
		int count = sc.nextInt();			
		if(count <= 0) {			
			System.out.println("오류! 양의 정숫값 입력 바람");		
		} else {			
			System.out.println("입력하신 숫자는 : " + count);		
			System.out.println("카운트 다운 시작");		
			for(int i = 0; i < count; i++) {		
				System.out.println(count - i + "...");	
				try { Thread.sleep(1000); } catch (Exception e) { }	
			}		
			System.out.println("발사!!!");		
		}
	}
}