package C;

public class CFood extends CProduct{
	String forPersons;	// 몇 인분
	String size;		// 곱빼기 등
	CFood(String name, int price) {//명시적 생성자 만듬
		super(name, price);			//CProduct꺼를 끌어옴
	
	}
}
