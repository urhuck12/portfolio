package C;
import java.util.Scanner;

public class Cplay {
	int biNengCount = 0;	
	int mulNengCount = 0;
	int bc=0;
	
	
	CFood biNeng;	// 비냉
	CFood mulNeng;	// 물냉
	
	Scanner sc = new Scanner(System.in);			
	String cmd = "";				
	
	public void run() { //기본 프로그램
			initData();
		boolean isNotEnd = true;			
		while(isNotEnd) {			
			dispGuide();
			cmd = sc.next(); // sc.next() 하는 순간 콘솔 창에서 우리의 입력을 기다리는 상태가 됨.		
			switch (cmd) {		
			case "1":		
				proc1();	
				break;	
			case "2":		
				proc2();	
				break;	
			case "exit":		
				isNotEnd = false;	
				break;
			default:
				System.out.println("없는 명령문 입니다");
				break;
			}		
		}	
		System.out.print("프로그램 종료");	
	}

	void proc1() { //1번 프로그램 분할 
		showMenues();
		boolean isNotEnd = true;
		while(isNotEnd) {
			dispGuide1();
			cmd = sc.next(); 
			switch (cmd) {
			case "1":
				
				proc1proc1();			
				break;
			case "2":
				if(biNengCount<9) {					
					biNengCount=biNengCount+1;					
				}
				proc1proc2();
				break;
			case "b":
				isNotEnd = false;
				break;
			default:
				System.out.println("없는 명령입니다.");
				break;
			}
		}
		System.out.print("back");	
	}

	void proc1proc1() { // 1번의1
		
		
//	System.out.println("선택한 물냉의 갯수: "+bc);
		mulNengCount++;
	System.out.println("물냉"+biNengCount);
	}
	void proc1proc2() {// 1번의2
	System.out.println("비냉");
	}


	void proc2() { //2번 분할
		boolean isNotEnd = true;
		while(isNotEnd) {
			dispGuide2();
			cmd = sc.next(); 
			switch (cmd) {
			case "1":				
				proc2proc1();
				break;
			case "2":
				proc2proc2();
				break;
			case "3":
				proc2proc3();
				break;
			case "b":
				isNotEnd = false;
				break;
			default:
				System.out.println("없는 명령입니다.");
				break;
			}
		}	
		System.out.print("back");	
	}
	void proc2proc1() {// 2번의3
		System.out.println("선택메뉴확인");
	}
	void proc2proc2() { // 2번의1
		System.out.println("결제");
	}
	void proc2proc3() {// 2번의2
		System.out.println("결제 취소");
	}




	void dispGuide() {//기본
		System.out.print(		
				"\n*******************\n"+
				"1. 주문하기 \n"+
				"2. 결제 \n"+			
				"b. back \n"+
				"*******************\n"+
				"명령:\n" );
	}
	
	void dispGuide1() {//1번
		System.out.print(		
				"\n*******************\n"+
				"1. 물냉 \n"+
				"2. 비냉 \n"+			
				"e. back \n"+
				"*******************\n"+
				"명령:\n" );
	}
	
	void dispGuide2() {//2번
		System.out.print(		
				"\n*******************\n"+
				"1. 선택 메뉴 재확인 \n"+
				"2. 결제 \n"+
				"3. 결제취소 \n"+
				"b. 뒤로가기 \n"+
				"*******************\n"+
				"명령:\n" );
	}
	void initData() {
		biNeng = new CFood("비빔 냉면",7000);	
		mulNeng = new CFood("물 냉면",6500);	
	}
	void showMenues() {				
		System.out.println(			
				"----------------- 메뉴판 ---------------"+"\n"			
				+ String.format("%20s%20s", biNeng.name, biNeng.getPriceWon()) + "\n"			
				+ String.format("%20s%20s", mulNeng.name, mulNeng.getPriceWon()) + "\n"+			
				"----------------- 메뉴판 ---------------"+"\n"			
				);				
	}
}
	// void proc3() { //  3번 분할
//	boolean isNotEnd = true;
//	while(isNotEnd) {
//		dispGuide3();
//		cmd = sc.next(); 
//		switch (cmd) {
//		case "1":
//			proc3proc1();
//			break;
//		case "2":
//			proc3proc2();
//			break;
//		case "e":
//			isNotEnd = false;
//			break;
//		default:
//			System.out.println("없는 명령입니다.");
//			break;
//		}
//	}	
//	System.out.print("3번 프로그램 종료");	
//}
//
//void proc3proc1() { // 3번의1
//System.out.println("3-1 프로그램");
//}
//void proc3proc2() {// 3번의1
//System.out.println("3-2 프로그램");
//}
// void dispGuide3() {//3번
//	System.out.print(		
//			"\n*******************\n"+
//			"1. 1번 프로그램 \n"+
//			"2. 2번 프로그램 \n"+
//			"3. 3번 프로그램 \n"+
//			"e. 프로그램 종료 \n"+
//			"*******************\n"+
//			"명령:\n" );
// 	}
	



