
public class Class1 {
	public static void main(String[] args) {
		int n = 1;
		int b = 2;
		int c = 3;
		int sum = n+b+c;
		System.out.println(sum);
		
		String a="개";
		String e="고양이";
		String f="너굴맨";
		
		System.out.println(a+e+f);
		

		for(int i=0; i<11; i++) {
			System.out.println(i);
		}
		
			
				
	}
}