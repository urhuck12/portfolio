
public class Strat {
	public static void main(String[] args) {
		 Monster mon= new Monster();
		 Player user= new Player();
		 initial(user,mon);
//		 mon.introduce();		
//		 user.introduce();
		 
		 mon.attackToPlayer(user, Monster.MONSTER_ATTACK_MINIMUM);
		 user.introduce();
		 user.attackToPlayer(mon,Player.PLAYER_ATTACK_MINIMUM);
		 mon.introduce();
//		 initial(user,mon);

		 user.Heal(user);
		 user.introduce(); 		 
	}
	public static void initial (Player p, Monster m) {
		p.introduce();
		m.introduce();
		System.out.println("\n");
		
	}
}