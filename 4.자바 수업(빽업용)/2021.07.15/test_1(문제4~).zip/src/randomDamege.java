
public class randomDamege {

	static int randomdamege (int min, int max){

	int Hit =(int)(Math.random()*min+max);
		return Hit;
	}
	
	static int Heal (int min, int max,int zero){
		int ran  = max - min +1;

		int heal =(int)(Math.random()*ran+min);
		return heal;
	}
	
}
