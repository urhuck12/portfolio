
public class Player {
	final static int PLAYER_INIT_HP = 200;	//유저 HP
	final static int PLAYER_INIT_MP = 100;	//유저 
	final static int PLAYER_ATTACK_HIT=10;	//랜덤최소값
	final static int PLAYER_ATTACK_CRI=15;	//랜덤최대값
	final static int PLAYER_HEAL_MIN=15;	//힐최소값
	final static int PLAYER_HEAL_MAX=19;	//힐최대값
	final static int PLAYER_HEAL_ZERO=0;	//크리티컬시 추가값으로 줄수있음
	
	final static int PLAYER_ATTACK_MINIMUM=0;//기본데미지
	
	String name;
	int hp,mp;

	Player(){
//		this.name= "유져";
//		this.hp= PLAYER_INIT_HP;
//		this.mp= PLAYER_INIT_MP;
		
		this("유저",PLAYER_INIT_HP,PLAYER_INIT_MP);

	}
	Player(String name, int hp, int mp) {
		this.name=name;
		this.hp=hp;
		this.mp=mp;
	}
	void introduce(){
		System.out.println("[이름: "+name+"] "+"[HP: "+hp+"] "+"[MP: "+mp+"] ");
	}
	void attackToPlayer(Monster mon, int damage) {
		int Hit =(int)(randomDamege.randomdamege(PLAYER_ATTACK_HIT,PLAYER_ATTACK_CRI));
		mon.hp = mon.hp - damage-Hit;
		System.out.print(String.format("%s가, %s에게, %d의 데미지를 주었습니다 "
				, name,mon.name,Hit));
	}
		
	void Heal(Player user) {
		int heal =(int)(randomDamege.Heal(PLAYER_HEAL_MIN,PLAYER_HEAL_MAX,PLAYER_HEAL_ZERO));
		user.hp = user.hp+heal;
		System.out.print(String.format("%s가 %d의 HP를 회복하였습니다 "
				, name,heal));
}			
	

}
