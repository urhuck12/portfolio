
public class Monster {
	final static int MONSTER_IN_HP=100;
	final static int MONSTER_IN_MP=100;
	final static int MONSTER_ATTACK_HIT=10;
	final static int MONSTER_ATTACK_CR=15;
	
	final static int MONSTER_ATTACK_MINIMUM=0;
	String name;
	int hp,mp;

	Monster(){
//		this.name= "고블린";
//		this.hp= 100;
//		this.mp= 100;
		this("야옹곰",MONSTER_IN_HP,MONSTER_IN_MP);

	}
	Monster(String name, int hp, int mp) {
		this.name=name;
		this.hp=hp;
		this.mp=mp;
	}
	void introduce(){
		System.out.println("[이름: "+name+"] "+"[HP: "+hp+"] "+"[MP: "+mp+"] ");
	}
	
	void attackToPlayer(Player user, int damage) {
		int Hit =(int)(randomDamege.randomdamege(MONSTER_ATTACK_HIT,MONSTER_ATTACK_CR));
		user.hp = user.hp - damage-Hit;
		System.out.print(String.format("야생의 %s이(가), %s에게, %d의 데미지를 주었습니다 "				, name,user.name,Hit));
	}	

}
