package com.peisia;

import com.peisia.obj.Monster;
import com.peisia.obj.Player;

public class EternalFantasyPlay {
	void play() {
		 Monster mon= new Monster();
		 Player user= new Player();
		 initial(user,mon);
//		 mon.introduce();		
//		 user.introduce();
		 
		 mon.attackToPlayer(user, Monster.MONSTER_ATTACK_MINIMUM);
		 System.out.println("\n");
		 user.attackToPlayer(mon,Player.PLAYER_ATTACK_MINIMUM);
//		 user.introduce();
//		 mon.introduce();
		 System.out.println("\n");
		 initial(user,mon);

		 user.Heal(user);
		 user.introduce(); 
		 
	}
	public void initial (Player p, Monster m) {
		// 개별 객체로 빠지는 경우 static이 필요가 없어짐
		p.introduce();
		m.introduce();
		System.out.println("\n");
		
	}

}
