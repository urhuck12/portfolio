package com.peisia;

import com.peisia.obj.Monster;
import com.peisia.obj.Player;

public class EternalFantasy {
	public static void main(String[] args) {
		
		EternalFantasyPlay efp= new EternalFantasyPlay();
		efp.play();
		
		 
	}

}