package C;

public abstract class CProduct {
	String name;
	int	price;
	CProduct(String name, int price){//생성자
		this.name = name;			
		this.price = price;
	}
	String getPriceWon() {	
		return price + "원";
	}	
}
