package C;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Cplay {
	int biNengCount = 0;	
	int mulNengCount = 0;
	int orderNo = 0;	
	
	CFood biNeng;	// 비냉
	CFood mulNeng;	// 물냉
	
	Scanner sc = new Scanner(System.in);			
	String cmd = "";				
	
	public void run() { //기본 프로그램
			initData();
		boolean isNotEnd = true;			
		while(isNotEnd) {			
			dispGuide();
			cmd = sc.next(); 		// sc.next() 하는 순간 콘솔 창에서 우리의 입력을 기다리는 상태가 됨.		
			switch (cmd) {		
			case "1":		
				procNewOrder();		//주문하기	
				break;	
			case "2":		
				procOrderCheck();	//주문확인
				break;	
			case "exit":			// 종료	
				isNotEnd = false;	
				break;
			default:
				System.out.println("없는 명령문 입니다");
				break;
			}		
		}	
		System.out.print("프로그램 종료");	
	}
	//------------------메뉴판 관련--------------------	
	void showMenues() {				
		System.out.println(			
			"----------- 메뉴판 ---------"+"\n"			
			+ String.format("%10s%5s", biNeng.name, biNeng.getPriceWon()) + "\n"			
			+ String.format("%11s%5s", mulNeng.name, mulNeng.getPriceWon()) + "\n"+			
			"----------- 메뉴판 ---------"+"\n"			
			);				
	}
	
	void initData() {
		biNeng = new CFood("비빔 냉면",7000);	
		mulNeng = new CFood("물 냉면",6500);	
	}	
	//------------------메뉴판 관련--------------------
	
	void procNewOrder() { //주문 메인창  
		showMenues();
		boolean isNotEnd = true;
		while(isNotEnd) {
			dispGuide1();			
			cmd = sc.next(); 
			switch (cmd) {
			case "1":		//물냉		
				procNewOrderMulNeng();			
				break;
			case "2":
				procNewOrderBiNeng();//비냉
				break;
			case "b":		 // 주문확인
				isNotEnd = false;
				break;
			default:
				System.out.println("없는 명령입니다.");
				break;
			}
		}
		System.out.print("back");	
	}
	
// ------------------1번 메뉴얼-----------------------
	void procNewOrderMulNeng() { // 1번의1		
		mulNengCount++;			// 갯수증가
	System.out.println("물냉"+mulNengCount); // 몇갠지 출력
	
	}
	void procNewOrderBiNeng() { // 1번의2
		biNengCount++;			// 갯수증가
	System.out.println("비냉"+biNengCount);// 몇갠지 출력
	}
// ------------------1번 메뉴얼-----------------------

	void procOrderCheck() { //주문확인 결제창
		
		boolean isNotEnd = true;
		while(isNotEnd) {
			dispGuide2();
			cmd = sc.next(); 
			switch (cmd) {
			case "1":				
				proc2proc1();		// 메뉴 재확인
				break;
			case "2":
				procPayment();		// 결제
				break;
			case "3":
				procOrderReset();	// 결제 취소
				break;
			case "b":				// 재주문
				isNotEnd = false;
				break;
			default:
				System.out.println("없는 명령입니다.");
				break;
			}
		}	
		System.out.print("선택완료");	
	}
	
	void showOrder() { //결제할 비용 계산
		System.out.println(								
			"----------------- 주문확인 --------------- \n	" 
			+ String.format("%4s수량:%3d개 가격:%5s", mulNeng.name, mulNengCount, mulNeng.price * mulNengCount +"원") + "\n"						
			+ String.format("%12s수량:%3d개 가격:%5s", biNeng.name, biNengCount, biNeng.price * biNengCount +"원") + "\n" 						
			+ "----------------- 총금액 ---------------\n"
			+ String.format("주문 총 가격: %10s", mulNeng.price * mulNengCount +biNeng.price * biNengCount +"원") + "\n" 
			);						
	}
	
	void showReceipt() {	//결제 화면창
		Date now = new Date();				
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분 ss초");				
		String strNow = sdf.format(now);				
		System.out.println("결제 되었습니다.");
		System.out.println(
			"----------------- 메뉴 교환권 --------------- \n"						
			+ String.format("주문번호: %3d", orderNo) + "\n"						
			+ String.format("%11s수량:%5d개 가격:%6s", mulNeng.name, mulNengCount, mulNeng.price * mulNengCount +"원") + "\n"						
			+ String.format("%10s수량:%5d개 가격:%6s", biNeng.name, biNengCount, biNeng.price * biNengCount +"원") + "\n"						
			+ String.format("결제 금액 : %8s", (mulNeng.price * mulNengCount + biNeng.price * biNengCount) + "원\n")
			+ String.format("결제 일시 : %8s", strNow)
			);
}
	
	void clearData() { // 입력된값 초기화
		biNengCount = 0;
		mulNengCount = 0;
	}
	
// ------------------2번 메뉴얼-----------------------	
	void proc2proc1() {// 선택 메뉴 재확인
		showOrder();
		System.out.println("위의 주문사항으로 주문하시겠습니까?");
	}
	void procPayment() { // 결제하기
		orderNo++; 		 // 결제 완료 시 위 값 1 증가시키기
		showReceipt();	 // 결제 화면창 출력
		clearData();	 // 입력된값 초기화 
		
	}
	void procOrderReset() {// 2번의3
		clearData();	 // 입력된값 초기화
		System.out.println("주문 작성이 취소되었습니다. 다시 주문 해 주세요");
	}
// ------------------2번 메뉴얼-----------------------

	void dispGuide() {//기본
		System.out.print(		
			"\n*******************\n"+
			"1. 주문하기 \n"+
			"2. 주문확인 \n"+			
			"b. 종료 \n"+
			"*******************\n"+
			"명령:\n" );
	}
	
	void dispGuide1() {//1번
		System.out.print(		
			"\n*******************\n"+
			"1. 물냉 \n"+
			"2. 비냉 \n"+			
			"b. 선택완료 \n"+
			"*******************\n"+
			"명령:\n" );
	}
	
	void dispGuide2() {//2번
		System.out.print(		
			"\n*******************\n"+
			"1. 선택 메뉴 재확인 \n"+
			"2. 결제 \n"+
			"3. 결제취소 \n"+
			"b. 재주문 \n"+
			"*******************\n"+
			"명령:\n" );
	}


}
	// void proc3() { //  3번 분할
//	boolean isNotEnd = true;
//	while(isNotEnd) {
//		dispGuide3();
//		cmd = sc.next(); 
//		switch (cmd) {
//		case "1":
//			proc3proc1();
//			break;
//		case "2":
//			proc3proc2();
//			break;
//		case "e":
//			isNotEnd = false;
//			break;
//		default:
//			System.out.println("없는 명령입니다.");
//			break;
//		}
//	}	
//	System.out.print("3번 프로그램 종료");	
//}
//
//void proc3proc1() { // 3번의1
//System.out.println("3-1 프로그램");
//}
//void proc3proc2() {// 3번의1
//System.out.println("3-2 프로그램");
//}
// void dispGuide3() {//3번
//	System.out.print(		
//			"\n*******************\n"+
//			"1. 1번 프로그램 \n"+
//			"2. 2번 프로그램 \n"+
//			"3. 3번 프로그램 \n"+
//			"e. 프로그램 종료 \n"+
//			"*******************\n"+
//			"명령:\n" );
// 	}
	



