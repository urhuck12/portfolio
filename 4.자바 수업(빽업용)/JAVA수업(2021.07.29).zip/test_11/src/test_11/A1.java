package test_11;

public class A1 {
	public static void main(String[] args) {
		
		for(int i=0; i<3; i++){



		  System.out.print(i);



		}
	}
}
