package com.peisia;

public class EternalFantasy {
	public static void main(String[] args) {
		
//		EternalFantasyPlay efp= new EternalFantasyPlay();
		EternalFantasyPlay efp= EternalFantasyPlay.getInstance();
		efp.play();
		
		 
	}

}