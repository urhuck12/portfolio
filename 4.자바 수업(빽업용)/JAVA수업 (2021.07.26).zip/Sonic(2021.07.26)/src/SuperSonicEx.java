
public class SuperSonicEx {
	public static void main(String[] args) {
		SuperSonic sa = new SuperSonic();
		sa.takeoff();
		sa.fly();
		sa.flyMode = SuperSonic.SUPERSONIC;
		sa.fly();
		sa.flyMode = SuperSonic.NORMAL;
		sa.fly();
		sa.land();
	}

}
