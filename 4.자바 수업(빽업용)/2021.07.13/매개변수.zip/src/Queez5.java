
public class Queez5 {
	public static void main(String[] args) {
		Monster mon= new Monster();
		mon.introduce();
		Player in= new Player();
		in.introduce();
		
		mon.attack(in, 20);
		in.introduce();
		
		in.attack(mon, 20);
		mon.introduce();
		
//		int iValue=(int)(Math.random()*10);
//		System.out.println(iValue);
	}
}
