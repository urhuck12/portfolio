
public class Monster {
	String name="";
	int hp=100;
	int mp=100;
	
	
	Monster(){//����
//		this.name="����";
//		this.hp=100;
//		this.mp=100;
		this("����",100,100);
	}
	Monster(String name, int hp, int mp){
		this.name=name;
		this.hp=hp;
		this.mp=mp;
//		this(name,hp,mp);
	}
	void introduce() {
		System.out.println("[�����̸�:"+name+"]"+"[hp:"+hp+"]"+"mp:"+mp+"]");
				
	}
	void attack(Player Player, int demage) {
		Player.hp = Player.hp - demage;
	}
}
