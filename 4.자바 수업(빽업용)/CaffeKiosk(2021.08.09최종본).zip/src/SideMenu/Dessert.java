package SideMenu;

import Main.Product;

public class Dessert extends Product{
	public String name;
	public int	price;
	public Dessert(String name, int price){
		this.name = name;			
		this.price = price;
	}

	String price() {	
		return price + "원";
	}
}
