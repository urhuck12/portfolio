package Main;



public abstract class Product {
	public static void main(String[] args) {
		
		Print mp = new Print();
		mp.run();
	}

	
}
