package Main;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;


import Drink.HotDrink;
import Drink.IecDrink;
import SideMenu.Dessert;

public class Print extends Product {
//************************선언************************************
		//갯수선언모음
	int americanoCount = 0;	
	int iceAmericanoCount = 0;	
	int vanillaLatteCount = 0;
	int iceVanillaLatteCount = 0;
	int cakeCount=0;
	int breadCount=0;
	int macaronCount=0;
		//주문번호
	int orderNo = 0; 	
//***************************************************************	
		//가격선언모음
	HotDrink americano = new HotDrink("아메리카노",3000);
	HotDrink vanillaLatte = new HotDrink("바닐라라떼",3500);
	
	IecDrink iceAmericano = new IecDrink("아이스아메리카노",3000);
	IecDrink iceVanillaLatte= new IecDrink("아이스바닐라라떼",3500);
	
	Dessert cake = new Dessert("케이크",4000);
	Dessert bread= new Dessert("브레드",5000);
	Dessert macaron= new Dessert("마카롱",2000);
	
	Scanner sc = new Scanner(System.in);			
	String cmd = "";				
	String passWerd = "";
//****************************************************************
//-------------------작업시작-------------------------------------

	public void run() { //기본 프로그램
		boolean repeat = true;
		while(repeat) {
			display();
			cmd=sc.next();
			switch(cmd) {
			case "1":
				order_IN();	//주문하기 실내
				break;
			case "2":
				order_OUT();//주문하기 실외
				break;
			case "3":
				payment();	//결제하기
				break;
			case "4":
				manager_MODE();	//관리자모드
				break;
			case "ex":		//종료
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
		}		
		System.out.println("프로그램 종료");			
	}
	
	//run -1 주문하기 실내
	void order_IN() {
		boolean repeat = true;
		while(repeat) {
//			order_INWarning();
			displayManu();
			cmd=sc.next();
			switch(cmd) {
			case "1":
				HotOrder();	//핫
				break;
			case "2":
				IceOrder();	//아이스
				break;
			case "3":
				dessert();	//디저트
				break;
			case "ex": 		//결제취소
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
		}	
		System.out.println("프로그램 종료");			
	}
	// IN 경고문구 뒤로 가기 할떄마다 계속 나와서 삭제함
//	void order_INWarning() {
//		System.out.println("해당메뉴는 매장내에서 드실수 있습니다");
//	}
	
	//run -1 주문하기 실외
	void order_OUT() {
		boolean repeat = true;
		while(repeat) {
//			order_OUTWarning();
			displayManu();
			cmd=sc.next();
			switch(cmd) {
			case "1":
				HotOrder();	//핫
				break;
			case "2":
				IceOrder();	//아이스
				break;
			case "3":
				dessert();	//디저트
				break;
			case "ex": 		//결제취소
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
		}		
		System.out.println("프로그램 종료");			
	}
	// OUT 경고문구 뒤로 가기 할떄마다 계속 나와서 삭제함
//	void order_OUTWarning() {
//		System.out.println("해당메뉴는 매장내에서 드실수 없습니다"
//							+"\n"+"포장만 가능합니다");
//	}
	
	//order -1
	void HotOrder() {
		boolean repeat = true;
		while(repeat) {
			displayHotManu();
			cmd=sc.next();
			switch(cmd) {
			case "1":
				HotOrder_AM();	// 아메리카노
				break;
			case "2":
				HotOrder_VL();	// 바닐라라떼
				break;
			case "3":	// 공란
				break;
			case "ex": 	// 뒤로가기
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
		}		
		System.out.println("프로그램 종료");			
	}
	//order -1 연결
	void HotOrder_AM() {
		americanoCount++;
		System.out.println("따뜻한 아메리카노 "+ americanoCount+"개");
	}
	void HotOrder_VL() {
		vanillaLatteCount++;
		System.out.println("따뜻한 바닐라라떼 "+ vanillaLatteCount+"개");
	}		
	
	//order -2
	void IceOrder() {
		boolean repeat = true;
		while(repeat) {
			displayIceManu();
			cmd=sc.next();
			switch(cmd) {
			case "1":
				IceOrder_AM();	// 아이스아메리카노
				break;
			case "2":
				IceOrder_VL();	// 아이스바닐라라떼
				break;
			case "3":	// 공란
				break;
			case "ex": 	// 뒤로가기
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
		}		
		System.out.println("프로그램 종료");			
	}
	//order -2 연결
	void IceOrder_AM() {
		iceAmericanoCount++;
		System.out.println("차가운 아메리카노 "+ iceAmericanoCount+"개");
	}
	void IceOrder_VL() {
		iceVanillaLatteCount++;
		System.out.println("차가운 바닐라라떼 "+ iceVanillaLatteCount+"개");
	}
	
	//order -3
	void dessert() {
		boolean repeat = true;
		while(repeat) {
			dessertManu();
			cmd=sc.next();
			switch(cmd) {
			case "1":
				dessert_CK();	// 케이크
				break;
			case "2":
				dessert_BD();	// 브레드
				break;
			case "3":
				dessert_MC();	// 마카롱
				break;
			case "ex": 	// 뒤로가기
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
		}		
		System.out.println("프로그램 종료");			
	}
	// order -3 연결
	void dessert_CK() {
		cakeCount++;
		System.out.println("케이크 "+ cakeCount+"개");
	}
	void dessert_BD() {
		breadCount++;		
		System.out.println("브레드 "+ breadCount+"개");
	}
	void dessert_MC() {
		macaronCount++;		
		System.out.println("브레드 "+ macaronCount+"개");
	}

//***************************************************************
	//run -3 결제하기
	void payment() {
		boolean repeat = true;
		while(repeat) {
			displayPayment();
			cmd=sc.next();
			switch(cmd) {
			case "1":
				payment_Reconfirm();//주문내역 재확인
				break;
			case "2":
				payment_Card();		//카드
				break;
			case "3":
				payment_Cash();		//현금
				break;
			case "4":
				payment_GiftCard(); //기프티콘
				break;
			case "5":
				clearData();		//주문취소
				break;
			case "ex":	//뒤로가기
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
		}
		System.out.println("프로그램 종료");			
	}
	//run -3 결제하기 연결
	void payment_Reconfirm() { //주문내역확인
		OrderPay();
		System.out.println("위의 주문사항으로 주문하시겠습니까?");
	}
	void payment_Card() { //카드결제
		orderNo++;
		OrderPay();
		totalPay();
		System.out.println("카드결제 되었습니다");
		clearData();
	}
	void payment_Cash() {	//현금결제
		orderNo++;
		OrderPay();
		totalPay();
		System.out.println("현금결제 되었습니다");
		clearData();
	}
	void payment_GiftCard() {	//상품권
		orderNo++;
		OrderPay();
		totalPay();
		System.out.println("기프트콘으로 결제되었습니다");
		clearData();
	}
	// 주문 재확인
	void OrderPay() { //결제할 비용 계산
		 
		if(americanoCount>0) {	//아메리카노 가격
			System.out.println(String.format("%11s 수량:%3d개 가격:%5s", 
			americano.name, americanoCount, americano.price * americanoCount+"원"));
		}	
		if (iceAmericanoCount>0) { //아이스아메리카노 가격
			System.out.println(String.format("%10s 수량:%3d개 가격:%5s",
			iceAmericano.name, iceAmericanoCount, iceAmericano.price * iceAmericanoCount+"원"));
		}
		if (vanillaLatteCount >0) {// 바닐라라떼 가격
			System.out.println(String.format("%11s 수량:%3d개 가격:%5s",
			vanillaLatte.name, vanillaLatteCount , vanillaLatte.price * vanillaLatteCount +"원"));
		}
		if (iceVanillaLatteCount >0) { // 아아스바닐라라떼 가격
			System.out.println(String.format("%10s 수량:%3d개 가격:%5s",
			iceVanillaLatte.name, iceVanillaLatteCount , iceVanillaLatte.price * iceVanillaLatteCount +"원"));
		}
		if (cakeCount >0) {	// 케이크가격
			System.out.println(String.format("%12s 수량:%3d개 가격:%5s",
			cake.name, cakeCount , cake.price * cakeCount +"원"));
		}
		if (breadCount >0) { //브레드 가격
			System.out.println(String.format("%12s 수량:%3d개 가격:%5s",
			bread.name, breadCount , bread.price * breadCount +"원"));
		}
		if (macaronCount >0) { // 마카롱 가격
			System.out.println(String.format("%12s 수량:%3d개 가격:%5s",
			macaron.name, macaronCount , macaron.price * macaronCount +"원"));
		}
	}
	// 주문 총 금액
	void totalPay() {
		Date now = new Date();				
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy년 MM월 dd일 hh시 mm분 ss초");				
		String paymentTime = sdf.format(now);
		System.out.println(
				String.format("주문번호: %3d", orderNo) + "\n"+
		
				String.format("결제 하실 금액: %5s",
				  (americano.price * americanoCount)
				+ (iceAmericano.price * iceAmericanoCount)
				+ (vanillaLatte.price * vanillaLatteCount)
				+ (iceVanillaLatte.price * iceVanillaLatteCount)
				+ (cake.price * cakeCount)
				+ (bread.price * breadCount)
				+ (macaron.price * macaronCount) +"원"+"\n"
				+ String.format("결제 일시 : %8s", paymentTime))
				);
	}
	// 입력된값 초기화
	void clearData() { 
		americanoCount = 0;
		iceAmericanoCount = 0;
		vanillaLatteCount = 0;
		iceVanillaLatteCount = 0;
		cakeCount = 0;
		breadCount = 0;
		macaronCount = 0;
		
	}
//**********************************************************	
	//run -4 관리자모드
	void manager_MODE() {		
		passWerd = "1234";
		managerPassWerd();
		boolean repeat = true;
		while(repeat) {			
			cmd=sc.next();
			switch(cmd) {
			case "1234":
				manager_MENU();				
				break;
			case "2":	
				repeat = false;
				break;
			default:
				System.out.println("비밀번호가 틀립니다.");
				break;
			}
			System.out.println("프로그램 종료");			
		}
	}
	// 관리자모드 경고문구
	void managerPassWerd() {
		System.out.println("관리자 비밀번호를 입력하세요");
	}
	//run -4 관리자모드 -1
	void manager_MENU() {
		managerMain();
		boolean repeat = true;
		while(repeat) {			
			cmd=sc.next();
			switch(cmd) {
			case "1":	//정산
				manager_MENU_BalanceAccounts();
				break;
			case "2":	//관리자 비밀번호 변경 차후 진행
				break;
			case "ex":	//돌아가기
				repeat = false;
				break;
			default:
				System.out.println("사용할수 없는 번호 입니다.");
				break;
			}
			System.out.println("프로그램 종료");			
		}
	}
	void  manager_MENU_BalanceAccounts() {//정산 예쩡
		
	}	
//**********************************************************
	//화면출력
	void display() {// 시작화면
		System.out.println(		
				"\n*******************\n"+
						"1. 매장주문 \n"+
						"2. 포장주문 \n"+
						"3. 주문확인 \n"+			
						"4. 관리자모드 \n"+			
						"ex. 종료 \n"+
						"*******************\n"+
						"명령:\n" );
	}	

	void displayManu() { //메뉴창 기본 -1
		System.out.println(		
				"\n*******************\n"+
						"1. 뜨거운음료 \n"+
						"2. 차가운음료 \n"+			
						"3. 디저트 \n"+			
						"ex. 메인메뉴로 돌아가기 \n"+
						"*******************\n"+
						"명령:\n" );
	}
	void displayHotManu() { //메뉴창 뜨거운음료
		System.out.println(		
				"\n*******************\n"+
						"1. 아메리카노 \n"+
						"2. 바닐라라떼 \n"+			
						"ex. 선택완료 \n"+
						"*******************\n"+
						"명령:\n" );
	}
	void displayIceManu() { //메뉴창 차가운음료
		System.out.println(		
				"\n*******************\n"+
						"1. 아이스아메리카노 \n"+
						"2. 아이스바닐라라떼 \n"+			
						"ex. 선택완료 \n"+
						"*******************\n"+
						"명령:\n" );
	}
	void dessertManu() { 	//메뉴창 디저트
		System.out.println(		
				"\n*******************\n"+
						"1. 케이크 \n"+
						"2. 브레드 \n"+			
						"2. 마카롱 \n"+			
						"ex. 선택완료 \n"+
						"*******************\n"+
						"명령:\n" );
	}
	void displayPayment() { //결제창 -2
		System.out.println(		
				"\n*******************\n"+
						"1. 주문내역확인 \n"+
						"2. 카드결제 \n"+
						"3. 현금결제 \n"+			
						"4. 기프티콘 \n"+			
						"4. 주문취소 \n"+			
						"ex. 추가 주문 하러가기 \n"+
						"*******************\n"+
						"명령:\n" );
	}
	void managerMain() { 	//관리자메인
		System.out.println(		
				"\n*******************\n"+
						"1. 정산 \n"+									
						"2. 관리자 비밀번호 변경 \n"+									
						"ex. 종료하기 \n"+
						"*******************\n"+
						"명령:\n" );
	}

	
}