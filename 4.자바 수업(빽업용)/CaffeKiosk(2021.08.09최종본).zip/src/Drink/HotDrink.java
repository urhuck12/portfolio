package Drink;

public class HotDrink extends DrinkMain{
	String extrashot;	// 샷 추가 
	String size;		// 곱빼기 등
	public HotDrink(String name, int price) {
		super(name, price);

	}


}
