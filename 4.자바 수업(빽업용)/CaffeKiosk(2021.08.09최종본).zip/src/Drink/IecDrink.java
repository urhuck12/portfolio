package Drink;

public class IecDrink extends DrinkMain{
	String extrashot;	// 샷 추가
	String size;		// 곱빼기 등
	public IecDrink(String name, int price) {//명시적 생성자 만듬
		super(name, price);			//DrinkMain꺼를 끌어옴
	
	}
}
