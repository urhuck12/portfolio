package Drink;

import Main.Product;

public class DrinkMain extends Product{
	public String name;
	public int	price;
	DrinkMain(String name, int price){
		this.name = name;			
		this.price = price;
	}
	String price() {	
		return price + "원";
	}
}
