package P1;

public class A {
	void sound() { 
		System.out.println("소리"); }		
}
