package P1;

public class M {
	public static void main(String[] args) {
		A a= new A();
		B b= new B();
		C c= new C();
		D d= new D();
		E e= new E();
		
		A a1 = b;
		A a2 = c;
		A a3 = d;
		A a4 = e;
//		B b1= d;
//		C c1 =e;

		
		a.sound();
		a1.sound();
//		c.run();
//		a2.run(); 형변환 이후에는 자기 함수를 쓸수없음.
		a2.sound();
		a3.sound();
		a4.sound();
		
		A as[]= {a,a1,a2,a3,a4};
//		A as1[]= {a,b,c,d,e}; 위에랑 똑같이 쓸수있음. 자동 형변환이됨.
		
		for(int i=0; i<as.length; i++) {
			as[i].sound();
		}
		
		
//		B b3 = e; 상속관계에 있지않아 사용할수 없음.
//		C c2 = d;
	}

}
