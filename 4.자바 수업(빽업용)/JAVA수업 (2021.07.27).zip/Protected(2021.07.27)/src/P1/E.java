package P1;

public class E extends C{
	void sound(){
		System.out.println("사람소리");
	}

}
