package P1;

public class B extends A{
	void sound(){
		System.out.println("동물소리");
	}
}
