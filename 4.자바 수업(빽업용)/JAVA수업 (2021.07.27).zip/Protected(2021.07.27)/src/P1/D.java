package P1;

public class D extends B {
	void sound(){
		System.out.println("고양이소리");
	}

}
