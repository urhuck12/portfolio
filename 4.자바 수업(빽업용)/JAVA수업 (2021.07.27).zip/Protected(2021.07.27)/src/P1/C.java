package P1;

public class C extends A{
	void sound(){
		System.out.println("케릭터소리");
	}

}
