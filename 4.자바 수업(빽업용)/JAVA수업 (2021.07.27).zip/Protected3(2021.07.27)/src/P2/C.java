package P2;

import P1.A;

public class C {
	public void method() { //extends A 가져와야쓸수있음
		
		A a= new A();
		a.field = "value";
		a.method();		//패키지가 다를대 가져올수없음
	}
}
