package P2;

import P1.A;

public class D extends A {
	
	public D(){
		super();
		this.field = "value";
		this.method();
	}

}
