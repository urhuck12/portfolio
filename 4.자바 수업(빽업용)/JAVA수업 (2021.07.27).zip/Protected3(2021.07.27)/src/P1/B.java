package P1;

public class B {
	public void method() {
		A a= new A();
		a.field = "value";
		a.method();
	}
}
