package com.peisia;

import com.peisia.obj.GameObj;
import com.peisia.obj.Monster;
import com.peisia.obj.Player;
import com.peisia.obj.Weapon;

public class EternalFantasy {
	public static void main(String[] args) {
		
		
//		EternalFantasyPlay efp= new EternalFantasyPlay();
		EternalFantasyPlay efp= EternalFantasyPlay.getInstance();
		efp.play();
		
		Player Player = new Player();
		Monster Monster = new Monster();
		Weapon Weapon = new Weapon();
		
		GameObj so[]= {Player,Monster,Weapon};
		
		for(int i=0; i<so.length; i++) {
			so[i].desc();
			if(so[i] instanceof Weapon){// 원형이 Weapon인 애를 찾음.
				Weapon wp=(Weapon)so[i];// GameObj로 형변환한걸 다시 재형변환해서 본 Weapon으로 속성이 바뀜
				wp.hit();				//Weapon쪽에 hit 메소드를 만듬
			}
		}
		test(Weapon);		 
	}

	public static void test(GameObj g) {
		g.desc();
	}
	

}