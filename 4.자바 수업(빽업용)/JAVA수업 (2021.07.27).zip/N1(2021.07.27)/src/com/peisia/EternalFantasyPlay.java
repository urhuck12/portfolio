package com.peisia;

import com.peisia.obj.Monster;
import com.peisia.obj.Player;
import com.peisia.util.Time;

public class EternalFantasyPlay extends Time{
	//정적필드
	private static EternalFantasyPlay sing = new EternalFantasyPlay();
	//생성자
	private EternalFantasyPlay() {}
	//정적 메소드
	static EternalFantasyPlay getInstance() {
		return sing;
	//외부에서 new클레스를 쓸수없게 만드는 형태.
	}	
	
	void play() {
		 Monster mon= new Monster();
		 Player user= new Player();
		 miniStatDisplay(user,mon);
//		 mon.introduce();		
//		 user.introduce();
		 Time.sleepSec(2);		
		 
		 mon.attackToPlayer(user, Monster.MONSTER_ATTACK_MINIMUM);
		 miniStatDisplay(user,mon);
		 Time.sleepSec(2);
//		 try {//지연효과를 주는거 딜레이
//			 Thread.sleep(3000L);//밀리초 단위임. 1000=1초
//		 } catch(Exception e) {		 
//		 }
		 user.attackToPlayer(mon,Player.PLAYER_ATTACK_MINIMUM);
		 miniStatDisplay(user,mon);
		 Time.sleepSec(2);
//		 try {//지연효과를 주는거 딜레이
//			 Thread.sleep(3000L);//밀리초 단위임. 1000=1초
//		 } catch(Exception e) {		 
//		 }
//		 initial(user,mon);

		 user.Heal(user);
		 miniStatDisplay(user,mon);
		
		 
	}
	
	public void miniStatDisplay (Player p, Monster m) {
		// 개별 객체로 빠지는 경우 static이 필요가 없어짐
		p.introduce();
		m.introduce();
		System.out.println("\n");		
	}
}