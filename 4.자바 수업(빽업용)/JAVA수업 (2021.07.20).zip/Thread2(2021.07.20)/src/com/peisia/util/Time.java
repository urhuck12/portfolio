package com.peisia.util;

public class Time {
	public static void sleepSec(int sec) {

		long lSec = sec * 1000;
		try {Thread.sleep(lSec);}
		catch(Exception e) {}
	}
}

