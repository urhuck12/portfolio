package com.peisia;

import com.peisia.obj.Monster;
import com.peisia.obj.Player;

public class EternalFantasyPlay {
	//정적필드
	private static EternalFantasyPlay sing = new EternalFantasyPlay();
	//생성자
	private EternalFantasyPlay() {}
	//정적 메소드singLeton
	static EternalFantasyPlay getInstance() {
		return sing;
	//외부에서 new클레스를 쓸수없게 만드는 형태.
	}
	
	
	void play() {
		 Monster mon= new Monster();
		 Player user= new Player();
		 initial(user,mon);
//		 mon.introduce();		
//		 user.introduce();
		 
		 mon.attackToPlayer(user, Monster.MONSTER_ATTACK_MINIMUM);
		 System.out.println("\n");
		 user.attackToPlayer(mon,Player.PLAYER_ATTACK_MINIMUM);
//		 user.introduce();
//		 mon.introduce();
		 System.out.println("\n");
		 initial(user,mon);

		 user.Heal(user);
		 user.introduce(); 
		 
	}
	public void initial (Player p, Monster m) {
		// 개별 객체로 빠지는 경우 static이 필요가 없어짐
		p.introduce();
		m.introduce();
		System.out.println("\n");
		
	}

}
