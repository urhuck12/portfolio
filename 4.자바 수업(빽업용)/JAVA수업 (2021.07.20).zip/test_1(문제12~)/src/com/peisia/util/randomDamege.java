package com.peisia.util;

public class randomDamege {

	public static int randomdamege (int min, int max){

	int Hit =(int)(Math.random()*min+max);
		return Hit;
	}
	
	public static int Heal (int min, int max,int zero){
		int ran  = max - min +1;

		int heal =(int)(Math.random()*ran+min);
		return heal;
	}
	
}
