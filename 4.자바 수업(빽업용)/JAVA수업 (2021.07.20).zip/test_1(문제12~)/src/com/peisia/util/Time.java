package com.peisia.util;

public class Time {

	protected static void sleepSec(int sec) {
		long lSec= (long)(sec*1000);
		try {Thread.sleep(lSec);}
		catch(Exception e) {}
		}
	}


