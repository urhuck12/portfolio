package com.peisia;

import com.peisia.obj.Monster;
import com.peisia.obj.Player;
import com.peisia.util.Time;

public class EternalFantasyPlay extends Time{
	
	static EternalFantasyPlay sing = new EternalFantasyPlay();
	private EternalFantasyPlay() {}
	static EternalFantasyPlay getInstance() {
		return sing;
		}
	
	void play() {
		 Monster mon= new Monster();
		 Player user= new Player();
		 miniStatDisplay(user,mon);

		 Time.sleepSec(2);
//		 try {Thread.sleep(1500);}
//		 catch (Exception e) {}
//		 mon.introduce();		
//		 user.introduce();
		 
		 mon.attackToPlayer(user, Monster.MONSTER_ATTACK_MINIMUM);
		 miniStatDisplay(user,mon);
		 Time.sleepSec(2);
		 user.attackToPlayer(mon,Player.PLAYER_ATTACK_MINIMUM);
		 miniStatDisplay(user, mon);
		 Time.sleepSec(2);
//		 initial(user,mon);

		 user.Heal(user);
		 miniStatDisplay(user,mon); 		 
	}
	public static void miniStatDisplay (Player p, Monster m) {
		p.introduce();
		m.introduce();
		System.out.println("\n");

		
	}

}
