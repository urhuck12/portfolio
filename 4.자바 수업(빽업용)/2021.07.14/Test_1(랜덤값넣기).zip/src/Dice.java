
public class Dice {
	static int dice(int rangeEnd) {
		int n =(int)(Math.random()*rangeEnd+1);
				return n;
	}
			
		static int dice2(int rangeEnd, int corunt) {			
			//1~rangeEnd ����		
			int n = (int)(Math.random() * rangeEnd + 1)*corunt ;		
//			int b = (int)(Math.random() * corunt + 1);		
			return n;	// ������ ����	
		}	
		
		static int item(int min, int max, int zero) {
//			
//			int item =(int)(Math.random()*5+15);
//					return item; ���� �����
			int ran  = max - min +1;
			int item =(int)(Math.random()*ran+min);	
			return item;
		}
}

