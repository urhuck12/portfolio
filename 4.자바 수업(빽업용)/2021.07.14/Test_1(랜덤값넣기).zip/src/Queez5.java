
public class Queez5 {
	public static void main(String[] args) {
		Monster mon= new Monster();
		mon.introduce();
		Player in= new Player();
		in.introduce();

		
		mon.attack(in,Monster.MONSTER_DAMEGE_HIT);
		in.introduce();
		
		in.attack(mon, Player.PLAYER_DAMEGE_HIT);
		mon.introduce();
		
		in.healSelf();
		in.introduce();
		
//		int iValue=(int)(Math.random()*10);
//		System.out.println(iValue);
	}
}
