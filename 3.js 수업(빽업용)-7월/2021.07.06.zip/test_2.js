// 실행이 안되요 


window.onload = function () {

    function Log() {
        this.id = "";
        this.pw = "";
        this.name = "";
        this.email = "";

        this.introduse = function () {
            dw("id: " + this.id
                + "name: " + this.name
                + "email: " + this.email)
        }
    }

    var member_1 = new Log(); // 1번회원
    member_1.id = "log_1 ";
    member_1.pw = "1_log ";
    member_1.name = "회원1 ";
    member_1.email = "zzz@naver.com ";

    var member_2 = new Log(); // 2번회원
    member_2.id = "log_2 ";
    member_2.pw = "2_log ";
    member_2.name = "회원2 ";
    member_2.email = "zzzz@naver.com ";

    var member_3 = new Log(); // 3번회원
    member_3.id = "log_3 ";
    member_3.pw = "3_log ";
    member_3.name = "회원3 ";
    member_3.email = "zzzzz@naver.com ";
    var membership = new Array(3);
    membership[0] = member_1;
    membership[1] = member_2;
    membership[2] = member_3;

    var inid = document.getElementById("inid"); // 아이디 연결
    var inpw = document.getElementById("inpw"); // pw 연결
    var logbut = document.getElementById("logbut"); //버튼 연결

    logbut.onclick = cl(); //버튼 생성    

    var find= false;

    function cl() {
        find=false;         //초기화
        for(var i=0; i<3; i++){
            if(menubarship[i].id==id.value)
                find=true;
        }
    }
    if(find==true){ //실행처리
        alert();
    }
    else{
        alert();
    }

}