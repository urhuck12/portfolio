// //1. 클래스 선언

// function bluetooth(name, ipx, weight){
//     this.name = name;
//     this.ipx = ipx;
//     this.weight = weight;
// }
// // 2. 객체 생성

// var tsx_qcc = new bluetooth("펜톤", 7, 5);
// var v65 = new bluetooth("엠지텍", 7, 5);
// var v65_pro = new bluetooth("엠지텍프로", 8 , 5);
// // 3. 객체사용

// dw(tsx_qcc.name);
// br();
// dw(tsx_qcc.ipx);
// br();
// (tsx_qcc.weight);
// br();


// function bluetooth(name, ipx, weight){
//     this.name = name;
//     this.ipx = ipx;
//     this.weight = weight;

//     this.introduce = function(){
//         dw("제품이름 :"+ this.name + "방수도: " + this.ipx + " 무게: "+ this.weight+"g");
//     }
// }

// window.onload=function(){
//     var tsx_qcc = new bluetooth("펜톤 tsx_qcc ", 7, 5);
//     var v65 = new bluetooth("엠지텍 v65 ", 7, 5);
//     var v65_pro = new bluetooth("엠지텍프로 v65_pro ", 8 , 5);

//     tsx_qcc.introduce();
//     br();
//     v65.introduce();
//     br();
//     v65_pro.introduce();

// }

// 간략버전 .
// function Cat(){
//     this.catName = "";
//     this.catAge = 0;
// }

// kitty.catName = "키티";
// kitty.catAge =100;

// dw(kitty.catName)
// br();
// dw(kitty.catAge)
// br();

// function phone1(){
//     this.model = "";
//     this.ram = 0;

//     this.introduce = function(memory){
//         dw("기종: "+ this.model + " 메모리사양: " + this.ram 
//         +"g"+ "저장공간: " + memory);
//     }
// }

// var phone=new phone1();

// phone.model = "폰";
// phone.ram =8;

// phone.introduce("128g") 

function phone1() {
    this.model = "";
    this.ram = 0;
    this.num = 0;
    this.net = "5g";
    this.memory = "";
    this.weight = "";

    this.introduce = function () {
        dw("[no.]" + this.num + "기종: " + this.model + " 메모리사양: " + this.ram
            + "저장공간: " + this.memory + "무게" + this.weight + "네트워크: " + this.net);
    }
    this.introduce2 = function () {
        dw("/" + "[no.]" + this.num + "기종: " + this.model + " 메모리사양: " + this.ram
            + "저장공간: " + this.memory + "무게" + this.weight + "네트워크: " + this.net + "/");
    }
}



var ph = new Array(10); // 초기모델로 같은 값을 여러개 출력

for (var i = 0; i < 10; i++) { //num을 선언하고 선언한 값에 번호 넣어줌.
    ph[i] = new phone1;     
    ph[i].num = i + 1;
    ph[i].model = "스마트폰"
    ph[i].ram = "8g";
    ph[i].net = "5g";
    ph[i].memory = "128g";
    ph[i].weight = "185g";

}

ph[6].model = "삼성"; //개별로 문구 수정 가능함.

for (var i = 0; i < 10; i++) {
    if(i%2==1){
    ph[i].introduce();
}
else{
    ph[i].introduce2();
}
    br();
}

// var phone= new phone2();

// phone.model = "아이폰";
// phone.ram =8;

// var phone_1= new phone2()

// phone_1.model = "삼성폰";
// phone_1.ram =8;

// var ph = [phone, phone_1] // 클래스객체도 배열로 처리가능
