function dw(s){
    document.write(s);
}

function br(){
    dw("<br>");
}

function ih(divObj, htmlString){
    divObj.innerHTML = htmlString
}