// 실행이 안되요 

window.onload = function () {

    var inid = document.getElementById("inid"); // 아이디 연결
    var inpw = document.getElementById("inpw"); // pw 연결
    var logbut = document.getElementById("logbut"); //버튼 연결
    var inner = document.getElementById("inner"); // 내용출력
    var loginBox = document.getElementById("login"); // 로그인후 삭제하기위해서
    
    var in_id="";
    var in_pw="";
    
    logbut.onclick = cl; //버튼 생성    

    function cl() {         //버튼 실행

        in_id = inid.value;
        in_pw = inpw.value;
        st_log();
    }


    function st_log() {
    // function st_log(id,pw,name,email) < 이렇게 넣어줘도됨
        function Log() {
            this.id = ""; //멤버라고 불림
            this.pw = "";
            this.name = "";
            this.email = "";

            this.introduse = function () {//introduse =메소드
                dw("id: " + this.id         //멤버를 출력, introduse로 전체 끌어다 실행시에는 
                    + "name: " + this.name // 멤버 선언한 전부를 출력해야지만 나옴.
                    + "email: " + this.email)
            }
        }

        var member_1 = new Log(); // 1번회원 
        member_1.id = "log_1";
        member_1.pw = "1_log";
        member_1.name = "회원1";
        member_1.email = "zzz@naver.com ";

        var member_2 = new Log(); // 2번회원
        member_2.id = "log_2";
        member_2.pw = "2_log";
        member_2.name = "회원2";
        member_2.email = "zzzz@naver.com ";

        var member_3 = new Log(); // 3번회원
        member_3.id = "log_3";
        member_3.pw = "3_log";
        member_3.name = "회원3";
        member_3.email = "zzzzz@naver.com ";

        // var membership=[member_1, member_2, member_3];
        var membership = new Array(3);
        membership[0] = member_1;
        membership[1] = member_2;
        membership[2] = member_3;

        var isfind=0;

        for (var i = 0; i < 3; i++) {
            if (membership[i].id == in_id) { // id비교
                 isfind=100;
                if (membership[i].pw == in_pw) { // pw비교
                    alert("로그인완료");        //둘다 일치하면 
                    inner.innerHTML=            
                    " 이름: " + membership[i].id + "<br>"+
                    " 메일: " + membership[i].email + "<br>"+
                    "로그인되었습니다."   
                    
                    loginBox.style.display="none";
                    break;
                }
                else {
                    alert("비밀번호가 없음/틀립니다");//아이디는 맞고 비번틀렸을때
                }
            }
        }
        if(isfind==100){ //둘다 틀렸을때           
        }
        else{
            alert("id/비밀번호가 틀립니다")
            
        }
        
    }
}

