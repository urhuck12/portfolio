function Log() {
    this.id = ""; //멤버라고 불림
    this.pw = "";
    this.name = "";
    this.email = "";

    this.introduse = function () {//introduse =메소드
        dw("id: " + this.id         //멤버를 출력, introduse로 전체 끌어다 실행시에는 
            + "name: " + this.name // 멤버 선언한 전부를 출력해야지만 나옴.
            + "email: " + this.email)
    }
}

var member_1 = new Log(); // 1번회원 
member_1.id = "log_1";
member_1.pw = "1_log";
member_1.name = "회원1";
member_1.email = "zzz@naver.com ";

var member_2 = new Log(); // 2번회원
member_2.id = "log_2";
member_2.pw = "2_log";
member_2.name = "회원2";
member_2.email = "zzzz@naver.com ";

var member_3 = new Log(); // 3번회원
member_3.id = "log_3";
member_3.pw = "3_log";
member_3.name = "회원3";
member_3.email = "zzzzz@naver.com ";

// var membership=[member_1, member_2, member_3];
var membership = new Array(3);
membership[0] = member_1;
membership[1] = member_2;
membership[2] = member_3;

var inid, inpw, logbut, inner, loginBox
var mid_on, submit_on, id_sub
var in_id, in_pw, idsub
in_id = "";
in_pw = "";
idsub = "";
var isfind = 0;

window.onload = function () {
    //로그인영역연결
    inid = document.getElementById("inid"); // 아이디 연결
    inpw = document.getElementById("inpw"); // pw 연결
    logbut = document.getElementById("logbut"); //버튼 연결
    inner = document.getElementById("inner"); // 내용출력
    inner1 = document.getElementById("inner_1"); // 내용출력
    
    loginBox = document.getElementById("login"); // 로그인후 삭제하기위해서
    // var inner_1 = document.getElementById("inner1"); // 미드영역숨김
    // mid_on.style.display = "none";

    //회원가입영역
    mid_on = document.getElementById("mid_on"); // 미드영역연결
    idsub = document.getElementById("id_sub"); // id중복확인 버튼 연결
    id_txt = document.getElementById("id_txt"); // 회원가입 id
    submit_on = document.getElementById("submit"); // 회원가입버튼
    // mid_pagelink = document.getElementById("mid_pagelink"); // 미드영역으로 이동하기 위해서 연결

    // inner_1.onclick = members;
    logbut.onclick = cl; // 로그인버튼 생성
    idsub.onclick = id_sub; // id중복체크 버튼 생성    
    submit_on.onclick = on; // 회원가입버튼 생성
}
function cl() {         //버튼 실행

    in_id = inid.value;
    in_pw = inpw.value;
    st_log();
}

function on() {

    alert("회원가입완료");
}

// function mid_on() {//미드영역 숨긴거 초기화
//     mid_on.style.display = "";
// }

function id_sub() { // 아이디 중복체크
    
    idsub = id_txt.value;
    for (var i = 0; i < 3; i++) {
        if (idsub.length < 4) {
            alert("4글자이상 입력해주세요");
            break;
        }
        if (membership[i].id == idsub) { // id 중복비교
            isfind = 100;
            alert(idsub+"중복된 아이디 입니다");
            break;
        }
        else {
            alert(idsub+"중복된 아이디가 없습니다. 계속 진행가능합니다")
            break;
        }
        //for문 밖에 if문으로 진행하려했으나 계속 중복으로 팝업이 나와서 중복 if로 변경함.
        // if (isfind == 100) { //둘다 틀렸을때           
        // } else {
        //     alert("중복된 아이디가 없습니다. 계속 진행가능합니다")
        // }
    }
}

function st_log() { // 로그인
    // function st_log(id,pw,name,email) < 이렇게 넣어줘도됨
    for (var i = 0; i < 3; i++) {
        if (membership[i].id == in_id) { // id비교
            isfind = 100;
            if (membership[i].pw == in_pw) { // pw비교
                alert("로그인완료");        //둘다 일치하면 
                inner.innerHTML =
                    " 이름: " + membership[i].id + "<br>" +
                    " 메일: " + membership[i].email + "<br>" +
                    "로그인되었습니다."
                loginBox.style.display = "none";
                break;
            }
            else {
                alert("비밀번호가 없음/틀립니다");//아이디는 맞고 비번틀렸을때
            }
        }
    }

    if (isfind == 100) { //둘다 틀렸을때           
    } else {
        alert("회원정보가 일치하지않습니다")
        var result = confirm("회원가입을 하시겠습니까?");
        if (result) {
            mid_pagelink.style.onclick = mid_on;
        } else {
            alert("저런~ 2018년에는 꼭 모두 이루세요!!");
        }
    }
}


