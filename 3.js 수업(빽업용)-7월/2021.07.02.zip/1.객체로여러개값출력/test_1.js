//1. 클래스 선언

function bluetooth(name, ipx, weight){
    this.name = name;
    this.ipx = ipx;
    this.weight = weight;
}
// 2. 객체 생성

var tsx_qcc = new bluetooth("펜톤", 7, 5);
var v65 = new bluetooth("엠지텍", 7, 5);
var v65_pro = new bluetooth("엠지텍프로", 8 , 5);
// 3. 객체사용

dw(tsx_qcc.name);
br();
dw(tsx_qcc.ipx);
br();
(tsx_qcc.weight);
br();


function bluetooth(name, ipx, weight){
    this.name = name;
    this.ipx = ipx;
    this.weight = weight;

    this.introduce = function(){
        dw("제품이름 :"+ this.name + "방수도: " + this.ipx + " 무게: "+ this.weight+"g");
    }
}

window.onload=function(){
    var tsx_qcc = new bluetooth("펜톤 tsx_qcc ", 7, 5);
    var v65 = new bluetooth("엠지텍 v65 ", 7, 5);
    var v65_pro = new bluetooth("엠지텍프로 v65_pro ", 8 , 5);

    tsx_qcc.introduce();
    br();
    v65.introduce();
    br();
    v65_pro.introduce();

}

