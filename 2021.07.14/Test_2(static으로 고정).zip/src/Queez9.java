
public class Queez9 {
	public static void main(String[] args) {
		Monster mon= new Monster();
//		mon.introduce();
		Player in= new Player();
//		in.introduce();
		initial(in,mon);
		
		mon.attack(in,Monster.MONSTER_DAMEGE_HIT);
//		in.introduce();
		in.attack(mon, Player.PLAYER_DAMEGE_HIT);
//		mon.introduce();
		initial(in,mon);
		
	
		in.healSelf();
		in.introduce();
//		initial(in, mon);
		
//		int iValue=(int)(Math.random()*10);
//		System.out.println(iValue);
	}
	
	public static void initial (Player p, Monster m) {
		p.introduce();
		m.introduce();
		System.out.println("\n");
		
	}
}
