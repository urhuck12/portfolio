function br(){
    document.write("<br>");
}


// function calc(a,b){
//     return a+b;
// }

function return100(){ //  return100()을 실행시 함수안에 return값인 100이 실행됨
    return 100;
}

function returnz(a,b){
    var nnn= a+ b;
    return nnn;
}

var n2 = returnz(100,200); // 함수만들때 쓴 수식만 가져옴 
document.write(n2);         // 예: 함수에 a+b 해놓으면 출력시 
                            //함수옆에 100,200써놓으면 최종값은 300이 나옴

function displayString(s){
    document.write(s);
}
displayString("야옹이"); // 실행문이 함수안에 들어가있기떄문에 
                        // 바로 야옹이가 출력이됨.       
                        br();
function return10000(){
    return 10000;
    
}

var c =return10000();
document.write(c);
br();

function return1000plus2000(){
    return 1000+2000;
}
var d=return1000plus2000();
document.write(d);
br();

function returnNN(){
    var ab = 120;
    var ac = 100;
    var sum = ab+ac;
    return sum;
}
var sum1=returnNN();
document.write(sum1);

function st(s){
    document.write(s);
}
st("컁");
br();

function dis(ae){
    document.write(ae);
    br();    
}

dis(2000);

function cal(ba, bb,bc){
    var sum = ba * bb * bc;
    document.write("case 7 :" + sum);
    br();    
}
cal(10, 100, 1000);

var a=6;
var b=3;

function run36add(a,b){
    var d= a+b;
    return d;
}

document.write("a,b 더하기: " + run36add(a,b));		
br();
function run36sub(a,b){
    return a-b;
}
document.write("a,b 빼기: " + run36sub(a,b));
br();
function run36mul(a,b){
    
    return a*b;
}

document.write("a,b 곱하기: " + run36mul(a,b));		
br();
function run36div(a,b){
    
    return a/b;
    
}
document.write("a,b 나누기: " + run36div(a,b));
br();
function zid(a,b){
    return a+b;
}

document.write(zid(100,200));
br();

function zid1(a,b){
    return a-b;
}

document.write(zid1(100,200));


var a=100;
var b=200;
var c=300;


function run36div(a,b){
    
    return a+b;
    
}
document.write(run36div(a,b));