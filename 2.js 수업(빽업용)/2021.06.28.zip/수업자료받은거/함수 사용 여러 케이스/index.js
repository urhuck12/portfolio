function br(){
    document.write("<br>");
}
/* 함수 사용 case 2 */
function return100(){
    return 100;
}
/* 함수 사용 case 3 */
function return50plus60(){
    return 50+60;
}
/* 함수 사용 case 4 */
function returnNN(){
    var nn = 120;
    return nn;
}
/* 함수 사용 case 5 */
function displayString(s){
    document.write(s);
    br();    
}
/* 함수 사용 case 6 */
function displayNum(nnnn){
    document.write(nnnn);
    br();    
}
/* 함수 사용 case 7 */
function displayCalcNum(a, b){
    var sum = a + b;
    document.write("case 7 :" + sum);
    br();    
}
/* 함수 사용 case 8 */
function returnCalcNum(c, x){
    var sum = c + x;    // 내부 변수 sum 선언하고 받은 두값을 더해서 자기가 받음
    return sum; // 리턴
}

/* 함수 사용 case 2 */
var n2 = return100();    // 이걸 실행하면. 아래.
// var n = 100;    // <--- 이게 된거에요.
document.write(n2); br();

/* 함수 사용 case 3 */
var n3 = return50plus60();    // 이걸 실행하면. 아래.
document.write(n3); br();

/* 함수 사용 case 4 */
var n4 = returnNN();    // 이걸 실행하면. 아래.
document.write(n4); br();

/* 함수 사용 case 5 */
displayString("고양이");    // 이걸 실행하면. 아래.

/* 함수 사용 case 6 */
displayNum(1000);

/* 함수 사용 case 7 */
displayCalcNum(1000, 2000);

/* 함수 사용 case 8 */
var case8 = returnCalcNum(1000,5000);
document.write("case 8 :" + case8); br();
// var case8 = 6000;






