var n;
n = prompt("1~6까지 숫자중에서 하나를 골라 입력하세요")// 입력팝업창

var nn;
nn=Number(n); // prompt는 기본으로 문자열값임 숫자값으로 변환이 필요함.

document.write("선택숫자:" + n); //팝업창에 기재한거를 페이지에 다시 찍어냄

var randomDice6 = Math.floor(Math.random() * 6 + 1);


switch (randomDice6) {
    case 1:
        document.write("<img src='dice6_1.jpg'>");
        break;
    case 2:
        document.write("<img src='dice6_2.jpg'>");
        break;
    case 3:
        document.write("<img src='dice6_3.jpg'>");
        break;
    case 4:
        document.write("<img src='dice6_4.jpg'>");
        break;
    case 5:
        document.write("<img src='dice6_5.jpg'>");
        break;
    case 6:
        document.write("<img src='dice6_6.jpg'>");
        break;
}



if (randomDice6==n ){
    document.write("당첨")
}

else {
    document.write("꽝")
}

document.write("img src='dice6_'"+ randomDice6+ ".jpg");
// 입력한 숫자대로 이미지 표기가 됨.
