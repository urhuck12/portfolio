// todo : * 주사위 도박 만들기
function br() {
    document.write("<br>")
}
var userValue;
var comValue;

function user() {
    userValue = prompt("1부터6까지 숫자만")
    document.write("플레이어가 건 주사위 : " + userValue);
    br();
}
function displayuser() {
    switch (userValue) {
        case "1":
            document.write("<img src='dice6_1.jpg'>")
            break;
        case "2":
            document.write("<img src='dice6_2.jpg'>")
            break;
        case "3":
            document.write("<img src='dice6_3.jpg'>")
            break;
        case "4":
            document.write("<img src='dice6_4.jpg'>")
            break;
        case "5":
            document.write("<img src='dice6_5.jpg'>")
            break;
        case "6":
            document.write("<img src='dice6_6.jpg'>")
            break;            
    }
    br();br();
}

function Com() {
    comValue = Math.floor(Math.random() * 6 + 1);
    document.write("컴퓨터가 건 주사위 : " + comValue);
    br();
}

function displaycom() {
    switch (comValue) {
        case 1:
            document.write("<img src='dice6_1.jpg'>")
            break;
        case 2:
            document.write("<img src='dice6_2.jpg'>")
            break;
        case 3:
            document.write("<img src='dice6_3.jpg'>")
            break;
        case 4:
            document.write("<img src='dice6_4.jpg'>")
            break;
        case 5:
            document.write("<img src='dice6_5.jpg'>")
            break;
        case 6:
            document.write("<img src='dice6_6.jpg'>")
            break;
    }
    br();
}
function procResult() {
    if ( userValue == comValue) {
        document.write("당첨");
    }
    else{
    document.write("꽝");
    }
}

// todo: 변수 설정
// todo: 유저 주사위 처리 
user();
// todo: 주사위를 이미지로 처리(유저, 컴퓨터 따로)
displayuser();
// todo: 컴퓨터 주사위 처리
Com();
displaycom();
// todo: 결과처리 (주사위가 같으면 당첨, 아니면 꽝)
procResult();

// 숫자가 1씩 증가하는 거를 한줄씩 넘겨서 표시.
for (var i = 0 ; i < 10 ; i ++ ) {
    document.write ( i + "<br>" );
}
// 별이 하나씩 증가함 
var n="★";
for (var i = 1 ; i < 10 ; i=i+1 ) {
    document.write(s);
    n=n+"★";
    document.write ( "<br>"  );
}
// 중첩포문도 가능함. 기동횟수는 메인은 기본숫자만 
// 인포문은 메인포문숫자x인포문숫자

for (var i = 1 ; i < 10 ; i=i+1 ) {
    
    for (var n = 1 ; n <= i ; n=n+1 ) {
        document.write("★")
    }
    document.write ( "<br>"  );
}
//배열 = 값을 여러개 한군데 저장할수 있음
var arr = ["★", "※", "☆"];
// index, 번지, 주소, 몇번째에 해당하는 숫자
document.write(arr[0]);

for (var i = 0; i < arr.length; i++) { // 배열 arr의 모든 요소의 인덱스(index)를 출력함.    
    document.write(arr[i] + " ");    
}