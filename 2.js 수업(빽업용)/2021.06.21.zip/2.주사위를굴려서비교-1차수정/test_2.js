function br() {
    document.write("<br>")
}
// 함수 생성시 function 함수명() 을 기입후
// 실행문을 작성하고 () 사이에 html에 쓰이는 함수를 기입.
// 사용시 예 : br(); < ;로 끊어줘야 처리가됨 여러개중복시에도 한개씩 다 넣어야함.
// 함수안에 코드를 다 넣어서 사용도 가능함.
function all() {
    var n;
    n = prompt("1~6까지 숫자중에서 하나를 골라 입력하세요")
    nn = Number(n);
    var randomDice6 = Math.floor(Math.random() * 6 + 1);


    document.write("<img src='dice6_" + randomDice6 + ".jpg'>");
    if (randomDice6 == n) {
        document.write("당첨")
    }

    else {
        document.write("꽝")
    }
}

//all(); //사용처리를 하면 위에 함수안에 묶어놓은 내용들이 실행이됨.

var n; // 펑션 밖에 전역변수를 지정을 하고 시작해야함.
var ai;


function inputBet() {
    n = prompt("몇에 거시겠습니까? (1~6)"); 
}
function displayPlayerBet() {
    document.write("당신은 " + n + "에 걸었습니다. <br>");    
}
function runDice6() {
    ai = Math.floor(Math.random() * 6 + 1); //펑션안에 선언한 변수는 그 함수내에서만 사용가능 지역함수
    document.write(" ai가 주사위를 굴렸습니다.<br>");
    document.write("<img src='dice6_" + ai + ".jpg'>");
}
function br() {
    document.write("<br>");
    document.write("<br>");

}
function displayResult() {

    if (n == ai) {
        document.write(" *** YOU WIN *** ")
    } else {
        document.write(" *** YOU LOSE *** ")
    }
}
inputBet();
displayPlayerBet();
runDice6()
br()
displayResult()

// var n = prompt("몇에 거시겠습니까? (1~6)");

// document.write("당신은 " + n + "에 걸었습니다. <br>");
// document.write("주사위를 굴렸습니다.<br>");

// var randomDice6 = Math.floor(Math.random() * 6 + 1);

// document.write("<img src='dice6_" + randomDice6 + ".jpg'>");

// document.write("<br>");
// document.write("<br>");

// if( n == randomDice6 ) {
//     document.write(" *** YOU WIN *** ")
// } else {
//     document.write(" *** YOU LOSE *** ")
// }