
// var userValue;
// var user_num;
// var com_num;
// // 유저꺼
// function user() {
//     userValue = prompt("가위, 바위, 보중 하나를 선택");
//     document.write("유저가 선택한 : " + userValue);
//     br();
// // 

// function displayuser() {
//     switch (userValue) {
//         case ("가위"):
//             user_num=0;
//             break;
//         case ("바위"):
//             user_num=1;
//             break;
//         case ("보"):
//             user_num=2;
//             break;
//     }

// }


// // 컴터꺼

// var comValue = Math.floor(Math.random() * 3);

// function Com() {
//     comValue = Math.floor(Math.random() * 3);
//     document.write("컴퓨터가 낸거 : " + comValue);
//     br();
// }
// var a_1="가위";
// var b_1="바위";
// var c_1="보";

// function displaycom() {
//     switch (comValue) {
//         case 0:
//             document.write(a_1);
//             break;
//         case 1:
//             document.write(b_1);
//             break;
//         case 2:
//             document.write(c_1);
//             break;
//     }

// }


// // function procResult() {
// //     switch (comValue==userValue) {
// //         case 1:
// //             if (a == a_1) {
// //                 document.write("비겼다")
// //             }
// //             else if (a > c_1) {
// //                 document.write("이겼다")
// //             }
// //             break;
// //         case 2:
// //             if (b == b_1) {
// //                 document.write("비겼다")
// //             }
// //             else if (b > a_1) {
// //                 document.write("이겼다")
// //             }
// //             break;
// //         case 3:
// //             if (c == c_1) {
// //                 document.write("비겼다")
// //             }
// //             else if (c > b_1) {
// //                 document.write("이겼다")
// //             }
// //             else {
// //                 document.write("졌다")
// //             }
// //     }
// // }
// user();
// displayuser();
// com();
// displaycom();
// // procResult();

// // // document.write( Math.floor(Math.random() * d_1));
// // // 입력한 숫자대로 이미지 표기가 됨.

var com;
var user;

var btn_user1;
var btn_user2;
var btn_user3;

var puser_srp;
var pcom_srp;
var presult;

function user_s() {
    user = 1;
    puser_srp.innerHTML = "플레이어가 가위를 냈습니다";

    if (com == 1) {
        pcom_srp.innerHTML = "가위"
        presult.innerHTML = "비겼습니다"
    }
    else if (com == 2) {
        pcom_srp.innerHTML = "바위"
        presult.innerHTML = "졌습니다"
    }
    else {
        pcom_srp.innerHTML = "보"
        presult.innerHTML = "이겼습니다"
    }

}
function user_r() {
    user = 2;
    puser_srp.innerHTML = "플레이어가 바위를 냈습니다";

    if (com == 1) {
        pcom_srp.innerHTML = "가위"
        presult.innerHTML = "이겼습니다"
    }
    else if (com == 2) {
        pcom_srp.innerHTML = "바위"
        presult.innerHTML = "비겼습니다"
    }
    else {
        pcom_srp.innerHTML = "보"
        presult.innerHTML = "졌습니다"
    }
}
function user_p() {
    user = 3;
    puser_srp.innerHTML = "플레이어가 보를 냈습니다";
    

    if (com == 1) {
        pcom_srp.innerHTML = "가위"
        presult.innerHTML = "졌습니다"
    }
    else if (com == 2) {
        pcom_srp.innerHTML = "바위"
        presult.innerHTML = "이겼습니다"
    }
    else {
        pcom_srp.innerHTML = "보"
        presult.innerHTML = "비겼습니다"
    }
}

window.onload = function () {
    com = Math.floor(Math.random() * 3+1); // 컴퓨터가 랜덤으로 낼거
    // comValue = Math.floor(Math.random() * 6 + 1);

    btn_user1 = document.getElementById("a_s"); // 가위
    btn_user2 = document.getElementById("a_r"); // 바위
    btn_user3 = document.getElementById("a_p"); // 보

    puser_srp = document.getElementById("user_srp"); //플레이어가 낸 거
    pcom_srp = document.getElementById("com_srp"); // 컴퓨터가 낸거
    presult = document.getElementById("result"); // 승부값

    btn_user1.onclick = user_s; // 가위 버튼 눌렀을때 
    btn_user2.onclick = user_r; // 가위 버튼 눌렀을때 
    btn_user3.onclick = user_p; // 가위 버튼 눌렀을때 
}

//     btn_user2.addEventListener("mouseover",  user_r, false); //바위 위에 마우스를 올렸을때
//     btn_user3.addEventListener("mouseover", user_p, false) ; //보 위에 마우스를 올렸을때 

// }

