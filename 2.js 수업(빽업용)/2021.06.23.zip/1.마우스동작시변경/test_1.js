var popup;
var dice_1;
var dice_2;
var dice_3;

function run(){
    popup.style.color = " red ";
    dice_1.src = "dice6_1.jpg ";
    dice_2.src = "dice6_2.jpg ";
    dice_3.src = "dice6_3.jpg ";

}
function runOut(){
    popup.style.color = " blue ";
    dice_1.src = " dice6_4.jpg ";
    dice_2.src = " dice6_5.jpg ";
    dice_3.src = " dice6_6.jpg ";
}

window.onload = function(){
    popup = document.getElementById("popup");
    popup.addEventListener("mouseover", run, false);
    popup.addEventListener("mouseout", runOut, false);


    dice_1 = document.getElementById("dice_1");
    dice_1.addEventListener("mouseover", run, false);
    dice_1.addEventListener("mouseout", runOut, false);

    dice_2 = document.getElementById("dice_2");
    dice_2.addEventListener("mouseover", run, false);
    dice_2.addEventListener("mouseout", runOut, false);

    dice_3 = document.getElementById("dice_3");
    dice_3.addEventListener("mouseover", run, false);
    dice_3.addEventListener("mouseout", runOut, false);
}