
var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] // 5보다 큰수만 출력할때 
function a1() {
    var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for (i = 5; i < 10; i = i + 1) {
        dw(a[i]);
    }

}
a1();

br(); br();
function a2() {
    var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for (i = 0; i < 10; i = i + 1) { // 5보다 큰수만 출력할때 
        if (5 < a[i]) {
            dw(a[i]);
        }
    }
}
a2();

br(); br();
function a3() {
    var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for (i = 0; i < 10; i = i + 1) { // 3이상7이하 출력할때 
        if (3 <= a[i] && 7 > a[i]) {
            dw(a[i]);
        }
    }
}
a3();

br(); br();
function a4() {
    var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    for (i = 0; i < a.length; i = i + 1) { // 3이하or7이상 출력할때 
        if (3 >= a[i] || 7 < a[i]) {
            dw(a[i]);
        }
    }
}
a4();

br(); br();
function a5() {
    var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    a[6] = 100

    for (i = 0; i < a.length; i = i + 1) { // 7번째를 100으로 변경할때
        dw(a[i]);
    }
}
a5();

br(); br();
function a6() {
    var a = [1, 2, 3, 4, 5,];
    for (i = 0; i < a.length; i = i + 1) {
        var v = Math.floor(Math.random() * 5 + 1); //랜덤한수를 a안에 들어있는 수로만 표현
        a[i] = v;
        dw(a[i]);
    }
}
a6();

br(); br();
function a7() {
    var b = ["야옹", "", "야아아옹", "야아아아옹", "야아아아아옹"
        , "삐약", "삐이약", "삐이이약", "함정카드", ""]

    for (i = 0; i < b.length; i = i + 1) { // 빈문장을 제외한 나머지를 출력할때
        if (b[i].length == 0) {
            dw("");
        }
        else {
            dw(a[i]);
        }
    }
}
a7();

br(); br();
function a8() {
    var b = ["야옹", "", "야아아옹", "야아아아옹", "야아아아아옹"
        , "삐약", "삐이약", "삐이이약", "함정카드", ""]

    for (i = 0; i < b.length; i = i + 1) { // 빈문장을 다른문구로 대체할떄
        if (b[i].length == 0) {
            dw("없음");
        }
        else {
            dw(b[i]);
        }
    }
}
a8();

br(); br();
//로또 번호 6개를 중복없이만 처리할때.
function a9() {
    var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
        11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
        41, 42, 43, 44, 45];

    var v = [0, 0, 0, 0, 0, 0];
    aaa:
    for (var i = 0; i < 6; i++) {
        var r = Math.floor(Math.random() * a.length + 1); // 45까지 숫자를 랜덤하게 뽑음.
        v[i] = r;                                         //랜덤하게 뽑은 숫자를 v로 보냄
        for (i = 0; i < 6; i++) {                         //중복값 체크를 위해서 생성            
            if (v[i] == r) {                              // 랜덤값이 중복인지 체크 동일하면 
                continue aaa;                             //다시 랜덤값을 추출하기위에서 label 지정한쪽으로 이동함.
            }
        }
    }
    for (var i = 0; i < v.length; i++)              //v에 있는 숫자갯수만큼만  
        dw(v[i] + " ");                           //r에서 보낸 숫자를 출력
}

a9();
br(); br();

function a10() {
    var a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
        11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
        21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
        31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
        41, 42, 43, 44, 45];

    var myC = [1, 4, 27, 35, 37, 45];
    var ca = 0;
    var v = [0, 0, 0, 0, 0, 0];
    bbb:
    for (var i = 0; i < 6; i++) {
        var r = Math.floor(Math.random() * a.length + 1); // 45까지 숫자를 랜덤하게 뽑음.
        v[0] = r;                                         //랜덤하게 뽑은 숫자를 v로 보냄
        for (i = 0; i < 6; i++) {                         //중복값 체크를 위해서 생성            
            if (v[0] == myC[i]) {                              // 랜덤값이 중복인지 체크 동일하면 
                ca = ca + 1;
                continue bbb;           //다시 랜덤값을 추출하기위에서 label 지정한쪽으로 이동함.
            }
        }
        ccc:
        for (i = 0; i < 6; i++) {
            var r = Math.floor(Math.random() * a.length + 1);
            v[1] = r;
            if (v[1] == myC[i]) {
                ca = ca + 1;
                continue ccc;
            }
        }
        ddd:
        for (i = 0; i < 6; i++) {
            var r = Math.floor(Math.random() * a.length + 1);
            v[2] = r;
            if (v[2] == myC[i]) {
                ca = ca + 1;
                continue ddd;
            }
        }
        eee:
        for (i = 0; i < 6; i++) {
            var r = Math.floor(Math.random() * a.length + 1);
            v[3] = r;
            if (v[3] == myC[i]) {
                ca = ca + 1;
                continue eee;
            }
        }
        fff:
        for (i = 0; i < 6; i++) {
            var r = Math.floor(Math.random() * a.length + 1);
            v[4] = r;
            if (v[4] == myC[i]) {
                ca = ca + 1;
                continue fff;
            }
        }
        ggg:
        for (i = 0; i < 6; i++) {
            var r = Math.floor(Math.random() * a.length + 1);
            v[5] = r;
            if (v[5] == myC[i]) {
                ca = ca + 1;
                continue ggg;
            }
        }
        br(); br();
  
        

    }
    dw("내가 지정한번호 : "+ myC ); br();
    dw("추첨번호")
    for (var i = 0; i < v.length; i++) {             //v에 있는 숫자갯수만큼만  
        
        dw(v[i] + " ");                                 //r에서 보낸 숫자를 출력
    }
    br();
    switch (ca) {
        case 3:
            dw("5등입니다.");
            break;
        case 4:
            dw("4등입니다.");
            break;
        case 5:
            dw("3등입니다.");
            break;
        case 6:
            dw("1등입니다.");
            break;
        default:
            dw("꽝입니다.")
            break;
    }


}
a10();