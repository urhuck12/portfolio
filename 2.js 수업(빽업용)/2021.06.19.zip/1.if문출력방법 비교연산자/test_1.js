// alert("고양이"); 단순 팝업용

// var n = "고양이"
// document.write= n; 굳이 두번째줄 안써도 팝업뜸
// alert(n); 변수 팝업용

// var cata=2;
// var catw="종류"
// var catn="야옹이"

// document.write("<p id='cata'>"+ "나이" + cata +"살" ,"</p>" );
// document.write("종류"+ catw );
// document.write("이름"+ catn );
// alert(cata + catw + catn);

// const CAT_A ="[고양이 나이]";
// const CAT_W ="[고양이 종류]";
// const CAT_N ="[고양이 이름]";
// 상수는 대문자로만 쓴다. 고정값으로 많이 씀
// 예:CAT_A

// var x = Number("3") * Number("5");
// alert(x);
// 명시적은 문자타입을 미리 잡아주고 진행함 
// 예 숫자면 Number,  문자열 String, 불리언 Boolean, 숫자로변환 Object

// && 논리연산자 완성된 식이 정상일 경우에만 실행이됨 둘다 참이여야지만 실행됨 
//  || = or  (쉬프트 \) 둘중 하나만 참이여도 실행이됨
// != = not  
var a= 1;
var b= 2;
var c= 3;
var d= 4;
var e= 6;
var f= 6;

// 1. 변수를 사용 숫자 변수를 6개만드시고 값을 임의로 주시고
// 각 값을 if 조건문써서 if 식 한개만 크다 작다 비교만해서 ok 가 되면
if ( c < d && e < f ) {
    document.write("if 문이 정상 실행되지않음") // e와 f값이 같기때문
}

if ( a < b || c < d  ) {
    document.write("if 문이 정상 실행됨")
}

// 2. 변수를 사용  (1) 과 같게 하되 비교를 같다 로 변경
if (c == d && e == f ) {
    document.write("if 문이 정상 실행 되지않음")
}

if ( a == b || c == d ) {
    document.write("if 문이 정상 실행됨")
}
// 3. 변수를 사용 (1) 과 같게 하되  비교를 같지 않다로 변경
if (c != d && e != f ) {
    document.write("if 문이 정상 실행됨")
}
if ( a != b || c != d ) {
    document.write("if 문이 정상 실행되지않음 ")
}

// 4. 나머지를 구하는 % 를 이용해서 var a = 10; var b = 3; 의 결과를 구하되 
// 결과를 글로 설명을 넣어서 ex.10 % 3 = ㅇㅇㅇㅇ식으로 표현하세요
var z= 10;
var x= 3;
var sum;

sum= z%x;
document.write(sum);
var s= " z%x은"  + sum + " 입니다" ;

// 5. (1)번의 식을 && 를 사용해서 처리 ex. 
if ( a< f && b < c ){
    document.write ( " 조건이 맞아서 이걸 출력함 " )
}

// 6. (1)번의 식을 || 를 사용해서 처리 ex. 실행은 이거 그대로:
if ( a< f || b !=c ){
    document.write ( " 조건이 맞아서 이걸 출력함 " );
}

//7. (1)번의 식을		a < b 를 하나의 식 이라고 하고	(식 && 식) || (식 && 식)	으로 구성하여 처리
if ( (a< f && b !=c) || (a < b && c < d)){
    document.write ( " 조건이 맞아서 이걸 출력함 " );
} 

// 8. (7) 처럼 하되 (식 || 식) && (식 || 식)	
if ( (a< f || b !=c) && (a < b || c < d)){
    document.write ( " 조건이 맞아서 이걸 출력함 " );
} 

var random;
random = Math.floor(Math.random() * 6) + 1; // 1 ~ 6 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.		
document.write(random);

var random;
random = Math.floor(Math.random() * 4) + 1; 		
document.write(random);

var random;
random = Math.floor(Math.random() * 10) + 1; 	
document.write(random);

var random;
random = Math.floor(Math.random() * 100) + 1; 		
document.write(random);

var s= "주사위를 굴려 (" + random + ") 의 수가 나왔습니다 ";
document.write(s);

