function closePopup() {
    // alert("컁");//
    var popupWindow = document.getElementById("popup")//팝업 닫기창.
    popupWindow.style.display = "inline";
    popupWindow.style.color = "red";
    popupWindow.style.height = "600px";
    popupWindow.style.width = "600px";
    popupWindow.style.backgroundColor = "blue";
    popupWindow.style.transitionProperty = "width, height";
    popupWindow.style.transitionDuration = "1s";

}

