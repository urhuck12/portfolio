function br() {
    document.write("<br>")
}

var current = 1;
var answer;
var min_01;
var min_02;
var ueseAnswer; //빈칸에 입력한 정답 문자열 
// 1번문제
var m_1_01 = " 빈 칸에 들어갈 내용은 ? ";
var m_2_01 = "( ______ )는 개발하고 하는 소프트웨어의 사전 작업을 통하여 소프트웨어 개발을 쉽게 하도록 기본 틀을 만드는 것으로, 복잡한 개발을 체계적으로 접근하기 위 한 밑그림이라 할 수 있다. 학술적인 정의로는 권도형(2004)에 따르면 소프트웨어를 구 성하는 컴포넌트들의 상호 작용 및 관계, 각각의 특성을 기반으로 컴포넌트들이 상호 유기적으로 결합하는 소프트웨어의 진화를 위한 여러 가지 원칙들의 집합이라고 할 수 있다";
var m_3_01 = "소프트웨어 아키텍처";
// 2번문제
var m_1_02 = "소프트웨어 아키텍처의 활용에 대한 내용 중 틀린 것은?";
var m_2_02 = "1. 비교적 간단한 소프트웨어를 개발할 때에는 완성해야 하는 목적과 기능을 중점으로 설계하여도 품질에는 큰 문제가 없다.<br><br> "
+ "2. 소프트웨어의 기능이 복잡, 다양해짐에 따라, 그 기능을 목적에 알맞게 정의하여 분류하여야 하는 명제를 안게 되었다.<br><br>"
+ "3. 분류된 기능이 세분화되면 상호 간에 유기적으로 통합하는 과정이 매우 쉬워진다. <br><br>"
+ "4. 완전한 소프트웨어를 개발하기 위하여 각각의 기능적 특성을 사전에 파악하여 요구 분석 단계부터 설계 단계까지 분류된 기능과 함께 종합적인 시각으로 판단하는 것이 매우 필요해진다.<br><br>";
var m_3_02 = 3;
// 3번문제
var m_1_03 =" 다음은 무엇에 대한 내용인가?";
var m_2_03 = "UI 각각의 상세 내역을 확인하기 전에 먼저 큰 흐름을 살펴보아야 한다. 목적과 그에 맞는 용도, 개발 배경 등 가장 기본이 되는 사항을 확인하여야 하며, 서로 다른 부서 또는 조직 간의 관계와 역할에 대해 명확하게 이해하고 있어야 한다.";
var m_3_03 = "UI흐름 이해";
// 
var m_1_04 
var m_2_04
var m_3_04
// 
var m_1_05
var m_2_05
var m_3_05
// 
var m_1_06
var m_2_06
var m_3_06
// 
var m_1_07
var m_2_07
var m_3_07
// 
var m_1_08
var m_2_08
var m_3_08
// 
var m_1_09
var m_2_09
var m_3_09
// 
var m_1_10
var m_2_10
var m_3_10
// 
var m_1_11
var m_2_11
var m_3_11
// 
var m_1_12
var m_2_12
var m_3_12
// 
var m_1_13
var m_2_13
var m_3_13
// 
var m_1_14
var m_2_14
var m_3_14
// 
var m_1_15
var m_2_15
var m_3_15
// 
var m_1_16
var m_2_16
var m_3_16
// 
var m_1_17
var m_2_17
var m_3_17
// 
var m_1_18
var m_2_18
var m_3_18
// 
var m_1_19
var m_2_19
var m_3_19
// 
var m_1_20
var m_2_20
var m_3_20



function btnClick() {
    switch (current) {
        case 1:
            ueseAnswer = answer.value;
            if (ueseAnswer == m_3_01) {
                alert("정답");
            }
            else {
                alert("오답")
            }
            // 2번
            min_01.innerHTML = m_1_02;
            min_02.innerHTML = m_2_02;
            break;
        case 2:
            ueseAnswer = answer.value;
            if (ueseAnswer == m_3_02) {
                alert("정답");
            }
            else {
                alert("오답")
            }
            min_01.innerHTML = m_1_03;
            min_02.innerHTML = m_2_03;
            break;
        case 3:
            ueseAnswer = answer.value;
            if (ueseAnswer == m_3_03) {
                alert("정답");
            }
            else {
                alert("오답")
            }
    }
    current=current+1; 
}

window.onload = function () {
    min_01 = document.getElementById("min_01"); //문제
    min_02 = document.getElementById("min_02"); //보기or지문
    answer = document.getElementById("answer");     //정답를 입력하는공간 
    var but_answer = document.getElementById("but_answer"); //입력 후 확인 버튼

    but_answer.onclick = btnClick;

    min_01.innerHTML = m_1_01;
    min_02.innerHTML = m_2_01;


}