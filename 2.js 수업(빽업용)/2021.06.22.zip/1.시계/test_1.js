function br(){
    document.write("<br>")
}

// var now = new Date();

// document.write(" 현재 시간은 : "+ now.toLocaleTimeString());//시간
// br();br();
// document.write(" 현재 시간은 : "+ now.toLocaleString());//날짜+시간
// br();br();
// document.write(" 현재 Date : "+ now.getDate());//1  OO일
// br();br();
// document.write(" 현재 Day : "+ now.getDay());//2 요일, 월요일 기준 숫자로 예:월요일1화요일2
// br();br();
// document.write(" 현재 FullYear : "+ now.getFullYear());//3 년도
// br();br();
// document.write(" 현재 Hours : "+ now.getHours());//4 OO시
// br();br();
// document.write(" 현재 Milliseconds : "+ now.getMilliseconds());//5 천분의 1초
// br();br();
// document.write(" 현재 Minutes : "+ now.getMinutes());//6 OO분
// br();br();
// document.write(" 현재 UTCMonth : "+ now.getMonth());//7 
// br();br();
// document.write(" 현재 Seconds : "+ now.getSeconds());//8 OO초
// br();br();
// document.write(" 현재 Time : "+ now.getTime());//9 
// br();br();
// document.write(" 현재 TimezoneOffset : "+ now.getTimezoneOffset());//10
// br();br();
// document.write(" 현재 UTCDate : "+ now.getUTCDate());//11
// br();br();
// document.write(" 현재 UTCDay : "+ now.getUTCDay());//12
// br();br();
// document.write(" 현재 UTCFullYear : "+ now.getUTCFullYear());//13
// br();br();
// document.write(" 현재 UTCHours : "+ now.getUTCHours());//14
// br();br();
// document.write(" 현재 UTCMilliseconds : "+ now.getUTCMilliseconds());//15
// br();br();
// document.write(" 현재 UTCMinutes : "+ now.getUTCMinutes());//16
// br();br();
// document.write(" 현재 UTCMonth : "+ now.getUTCMonth());//17
// br();br();
// document.write(" 현재 UTCSeconds : "+ now.getUTCSeconds());//18
// br();br();
// document.write(" 현재 VarDate : "+ now.getVarDate());//19
// br();br();



// function time(){
// // document.write(" 현재 시간은 : "+ now.toLocaleString(),"  " + now.getMilliseconds());//날짜+시간
// document.write(now.getFullYear()+"년 ");//3 년도
// document.write(now.getMonth()+1 + "월 " );//7 
// document.write(now.getDate()+ "일 ");//1  OO일
// document.write(now.getHours()+ "시 ");//4 OO시
// document.write(now.getMinutes()+ "분 ");//6 OO분
// document.write(now.getSeconds()+ "초 ");//8 OO초
// document.write(now.getMilliseconds()+ "밀리초 ");
// }
// time();

// var year = now.getFullYear();
// var month = now.getMonth()+1;
// var date = now.getDate();
// var Hour = now.getHours();
// var Min = now.getMinutes();
// var sec = now.getSeconds(); 
// var mil = now.getMilliseconds();

// var s = year + "년 " + month + "월 " + data + "일 " 
//     + Hour + " 시" + Min + "분 " + sec + "초 "+ mil + "밀리초 ";

document.write(s);
function closePopup() {
    alert("컁");
}

