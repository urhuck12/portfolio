function dw(s){
    document.write(s);
}

function br(){
    dw("<br>");
}