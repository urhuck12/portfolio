function ar(a,b){ // 2개를 더할수있는 함수 생성
    var c = a + b;
    return c ;
}
// dw(ar(1,2));
br();
function ar1(){
    var c=ar(1,2);
    dw(c);
}
ar1();

br();
function ar2(){
    var c=ar(3,4);
    dw(c);
}
ar2();
br();

function ar3(){
    var z= ar(1,2); //지역변수로 하나 만들어서 처리시
   dw(ar(3,z));

//    dw(ar(3,ar(1,2))); 한줄로 처리시 다른 덧셈 함수 하나 끌어와서 사용
    
}
ar3();

br();
function ar4(){
    var q=ar(1,2);
    var w=ar(3,4);
    dw(ar(q,w));
}
ar4();
br();
function ar5(e,g,c,d){ //4개를 더할수있는 함수 생성
    var f=e+g+c+d ;
    return f;
}
br();
function ar6(){
    var k=ar5(1,2,3,4);
    var h=ar5(5,6,7,8);
    
    dw(ar(k,h));
    
}
ar6();
br();
function ar7(a){
    var a1= a[0];
    var a2= a[1];
    var a3= a[2];
    var a4= a[3];
    var l= a1+a2+a3+a4;
    
    return l;
    
}

br();
function ar8(){
    var k_1= [1,2,3,4]; //배열 선언
    var k_2= [5,6,7,8];
    var z= ar7(k_1);    //배열을 합산한다
    var x= ar7(k_2);

    var sum1=ar(z,x);   //배열을 다른함수를 써서 합산
    dw(sum1);           //출력
}
ar8();
br();
function ar9(a){
    var b1 =a[0] + a[1] + a[2];
    // var b2 =a[1];
    // var b3 =a[2];
    
    // var bb= b1+b2+b3;
    return b1;
}

function ar10(){
    var b_1=[2,4,6];
    // var b_2=[1,3,5];
    
    var ba=ar9(b_1);
    // var bc=ar9(b_2);

    
    // dw(ar(ba,bc));
    dw(ba);
}

ar10();

br();
var c=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
var b= c[6];
dw(b);
br();br();

var f=c[0];
var d=c[19];
dw(f);br();
dw(d);br();

dw(f+d); // 한줄로 f랑 d로 뺀 배열값을 합친거
br();

dw(c.length);   //배열갯수
br();br();

for (var i=0 ; i<20 ; i=i+1){
    dw(c[i]);br(); // 1~20까지 출력
}
br();

for (var i=0 ; i<c.length ; i=i+1){
    dw(c[i]);br(); // 1~20까지 출력 배열갯수만큼 적용이됨. 
}

var a=[1,2,3,4,5,6,7,8,9,10]
for (var i=0; i<a.length ; i++){
    dw(a[i]);
}
br();br();
var b=["야옹", "야아옹", "야아아옹", "야아아아옹", "야아아아아옹"
    , "삐약", "삐이약", "삐이이약", "함정카드", "삐이이이이약"]
for( var i=0; i<b.length; i=i+1){
    dw(b[i]);
}
br();br();

for( var i=0; i<b.length; i=i+1){  //특정문자가 몇번쨰에 있는지 찾을때 
    if (b[i]=="함정카드"){
        dw(i+1+"");
    }
}
br();br();
var find =0;
for( var i=0; i<b.length; i=i+1){
    if (b[i]=="함정카드"){
        find=i+1;
    }
}
dw(i+1+"");