var n = 0;
var random;
random = Math.floor(Math.random() * 6) + 1; 


switch(random-n){
    case 1:
        document.write("<p>스위치 케이스 1을 탔음 </p>")
        break;
    case 2:
        document.write("<p>스위치 케이스 2을 탔음 </p>")
        break;
    case 3:
        document.write("<p>스위치 케이스 3을 탔음 </p>")    
        break;
    case 4:
        document.write("<p>스위치 케이스 4을 탔음 </p>")    
        break;
    case 5:
        document.write("<p>스위치 케이스 5을 탔음 </p>")    
        break;
    default:
        document.write("<p>스위치 케이스에 해당없을때 </p>")    
}