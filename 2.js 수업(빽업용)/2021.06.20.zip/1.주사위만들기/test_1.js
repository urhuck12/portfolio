

var random;
var a=6
var b=a-1
var c=b-1
var d=c-1
var e=d-1


random = Math.floor(Math.random() * 6) + 1;
 // 1 ~ 6 까지 범위내에서 랜덤하게 숫자 하나 뽑아주는 애.		
// var s= "주사위를 굴려 (" + random + ") 의 수가 나왔습니다 ";
// if (random == a || random == b || random == c) 개별 변수로 나눠서 넣어도 상관없음

if(random==1){
    alert("꽝")
}
else {
    alert((7-random)+ "등 입니다") // 등수만 나옴 if랑 else 두가지로 간략 표현할때.
}

// else if (random > 4) {
//     alert("주사위를 굴려 (" + random + ") 의 수가 나와 2등 당첨 되었습니다")
// }
// else if (random > 3) {
//     alert("주사위를 굴려 (" + random + ") 의 수가 나와 3등 당첨 되었습니다")
// }
// else if (random > 2) {
//     alert("주사위를 굴려 (" + random + ") 의 수가 나와 4등 당첨 되었습니다")
// }
// else if (random > 1) {
//     alert("주사위를 굴려 (" + random + ") 의 수가 나와 5등 당첨 되었습니다")
// }
// else {
//     alert("주사위를 굴려 (" + random + ") 의 수가 나와 꽝 당첨 되었습니다")
// }




var random;
random = Math.floor(Math.random() * 4) + 1; 		
document.write(random);

var random;
random = Math.floor(Math.random() * 10) + 1; 	
document.write(random);

var random;
random = Math.floor(Math.random() * 100) + 1; 		
document.write(random);

var s= "주사위를 굴려 (" + random + ") 의 수가 나왔습니다 ";
document.write(s);

document.write("주사위를 굴려(" + (Math.floor(Math.random() * 100) + 1+" ) 가 나왔습니다") )
// 한줄로 요약했을때
