package portfolioType1;

public class new_member {

}
