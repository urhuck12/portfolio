
//	셀렉트 박스 선택내용을 input으로 보내는거
function mail_shot(){
	 i=document.join.new_email3_box.selectedIndex 			// 선택항목의 인덱스 번호
	 var mail=document.join.new_email3_box.options[i].value // select박스안에 value값을 생성
	 document.join.new_email2_box.value=mail				//select박스에 선택한 value값을 input박스로 보냄
}

var new_id_ck,inID_no,inID_ok;
var new_pw_ck,inPW_no,inPW_ok;
var new_pwck_ck,inPWCK_no,inPWCK_ok;
var new_name_ck,inNAME_no,inNAME_ok;
var new_fbirth_ck,inBIRTH_no,inBIRTH_ok;
var new_morw_ck,inMORW_no,inMORW_ok;

var id_db = ["aaaaaa","bbbbbb"];// 임시db값

window.onload = function(){
	
	new_id_ck=document.getElementById("new_id_box");	// id입력 input박스 연결
	new_pw_ck=document.getElementById("new_pw_box");	// pw입력 input박스 연결
	new_pwck_ck=document.getElementById("new_pwck_box");// pwck입력 input박스 연결
	new_name_ck=document.getElementById("new_name_box");// pwck입력 input박스 연결
	new_fbirth_ck=document.getElementById("F_birth");		// F_birth입력 input박스 연결
	new_morw_ck=document.getElementById("morw");		// F_birth입력 input박스 연결
	
	inID_no=document.getElementById("id_x");			// id_x innerHTML영역 연결
	inID_ok=document.getElementById("id_ok");			// id_ok innerHTML영역 연결
	
	inPW_no=document.getElementById("pw_x");			// pw_x innerHTML영역 연결
	inPW_ok=document.getElementById("pw_ok");			// pw_ok innerHTML영역 연결
	
	inPWCK_no=document.getElementById("pwck_x");		// pwck_x innerHTML영역 연결
	inPWCK_ok=document.getElementById("pwck_ok");		// pwck_ok innerHTML영역 연결

	inNAME_no=document.getElementById("name_x");		// pwck_x innerHTML영역 연결
	inNAME_ok=document.getElementById("name_ok");		// pwck_ok innerHTML영역 연결

	inBIRTH_no=document.getElementById("Birth_x");		// pwck_x innerHTML영역 연결
	inBIRTH_ok=document.getElementById("Birth_ok");		// pwck_ok innerHTML영역 연결

	inMORW_no=document.getElementById("morw_x");		// pwck_x innerHTML영역 연결
	inMORW_ok=document.getElementById("morw_ok");		// pwck_ok innerHTML영역 연결	
	/*id_db 나중에 db연결했을떄 아이디 중복값 거를용도로 쓸거*/ 
	}
	
function check_Id() {

	var isID = /^[a-z0-9][a-z0-9_\-]{4,9}$/;			// 숫자,영어,특수문자만 사용가능하게함
    if ( new_id_ck.value== "" || new_id_ck.value==null ) { //입력값이 없을때
		inID_no.innerHTML = "필수 정보입니다";
    }else if (new_id_ck.value.search(/\s/) != -1){			// 공백입력했을떄
		inID_no.innerHTML ="ID에는 공백을 사용할수 없습니다.";
		return;
    }else if (!isID.test(new_id_ck.value)) {				//한글들어갔을때
        inID_no.innerHTML ="5~10자의 영문 소문자, 숫자와 특수기호(_),(-)만 사용 가능합니다.";
		inID_ok.innerHTML ="";								//초기화
		return;
	}else {
		for(var i=0; i<id_db.length; i++ ){					//중복값체크위해서 만듬
			if(new_id_ck.value == id_db[i]){				//중복값일때
			inID_no.innerHTML=id_db[i]+"중복 아이디 입니다";
			inID_ok.innerHTML ="";							//초기화
			return;
		} else if(new_id_ck.value != id_db[i]){				//중복이 아닐때
			inID_ok.innerHTML="사용가능한 아이디 입니다";
			inID_no.innerHTML ="";							//초기화
			return;
			}
		}
	}	
}

function check_PW() {

	var isPW = /^[a-z0-9][a-z0-9_\-]{7,14}$/;				// 숫자,영어,특수문자만 사용가능하게함
    if ( new_pw_ck.value== "" || new_pw_ck.value==null ) { //입력값이 없을때
		inPW_no.innerHTML = "필수 정보입니다";
    }else if (new_pw_ck.value.search(/\s/) != -1){			// 공백입력했을떄
		inPW_no.innerHTML ="PASSWORD에는 공백을 사용할수 없습니다.";
		return;
    }else if (!isPW.test(new_pw_ck.value)) {				//한글들어갔을때
        inPW_no.innerHTML ="8~15자의 영문 소문자, 숫자와 특수기호(_),(-)만 사용 가능합니다.";
		inPW_ok.innerHTML ="";								//초기화
		return;
	}
	else {		
		inPW_ok.innerHTML="사용가능한 PASSWORD 입니다";		
		inPW_no.innerHTML ="";
		return;			
		}
	}	



function check_PWCK() {
	
	if(new_pwck_ck.value== "" || new_pwck_ck.value==null) {		// 입력값이 없을때
		inPWCK_no.innerHTML ="입력된패스워드가 없습니다";
		inPWCK_ok.innerHTML ="";		
	}else if (new_pw_ck.value==new_pwck_ck.value)  {			// new_pw_ck와 입력값이 동일할때
	    inPWCK_ok.innerHTML = "패스워드가 일치합니다.";
		inPWCK_no.innerHTML ="";
		return;
	}else if (new_pwck_ck.value.search(/\s/) != -1){			// 공백입력했을때
		inPWCK_no.innerHTML ="PASSWORD에는 공백을 사용할수 없습니다.";
		return;
	}
	
	if (new_pw_ck.value != new_pwck_ck.value) {					// 일치하지 않을때, 해당 if문을 맨위로 올리면 작동안됨.. 이유를 모르겠음.
	    inPWCK_no.innerHTML = "패스워드가 일치하지 않습니다.";
		inPWCK_ok.innerHTML = "";		
	}		
}


function check_name() {
	
	var isNAME =  /[^?a-zA-Z0-9/]{1,4}$/;
    if ( new_name_ck.value== "" || new_name_ck.value==null ) { //입력값이 없을때
		inNAME_no.innerHTML = "필수 정보입니다 2글자~5글자까지 입력가능합니다 ";		
    }else if (new_name_ck.value.search(/\s/) != -1){			// 공백입력했을떄
		inNAME_no.innerHTML ="이름에는 공백을 사용할수 없습니다.";
		inNAME_ok.innerHTML ="";
		return;
	}else if(!isNAME.test(new_name_ck.value)) {
		inNAME_no.innerHTML = "필수 정보입니다 2글자~5글자까지 입력가능합니다. 숫자,특수문자등은 사용할수 없습니다.";	
		inNAME_ok.innerHTML ="";								//초기화
		return;
	}else if(new_name_ck.value.length<2){
		inNAME_no.innerHTML = "2글자~5글자까지 입력가능합니다.";
		inNAME_ok.innerHTML ="";	
		return;
	}else{
		inNAME_ok.innerHTML ="";
		inNAME_no.innerHTML ="";		
	}
}

//function check_birth(){ 생년월일용 이였으나 selcet로 처리해서 주석처리함. 2021.10.21
//
//	var isbirth =/^[0-9]{4}$/;
//	if ( new_fbirth_ck.value== "" || new_fbirth_ck.value==null ) { //입력값이 없을때
//		inBIRTH_no.innerHTML = "필수 정보입니다 생년 4자리 숫자를 입력해주세요 ";		
//    }else if (new_fbirth_ck.value.search(/\s/) != -1){			// 공백입력했을떄
//		inBIRTH_no.innerHTML ="생년에는 공백을 사용할수 없습니다.";
//		inBIRTH_ok.innerHTML ="";
//		return;
//	}else if(!isbirth.test(new_fbirth_ck.value)) {
//		inBIRTH_no.innerHTML = "필수 정보입니다 생년 4자리 숫자를 입력해주세요.";	
//		inBIRTH_ok.innerHTML ="";								//초기화
//		return;
//	}else if(new_fbirth_ck.value.length<4){
//		inBIRTH_no.innerHTML = "2글자~5글자까지 입력가능합니다.";
//		inBIRTH_ok.innerHTML ="";	
//		return;
//	}else{
//		inBIRTH_ok.innerHTML ="";
//		inBIRTH_no.innerHTML ="";		
//	}
//}

function check_morw(){
	
	switch(new_morw_ck.value){
		case "1" :
			inMORW_no.innerHTML = " 선택할수 없는 옵션입니다";
			inMORW_ok.innerHTML ="";
		return;
		case "2" :
			inMORW_ok.innerHTML = "";
			inMORW_no.innerHTML ="";
		return;
		case "3" :
			inMORW_ok.innerHTML = "";
			inMORW_no.innerHTML ="";
		return;
		case "4" :
			inMORW_no.innerHTML = " 선택할수 없는 옵션입니다";
			inMORW_ok.innerHTML ="";
		return;
	}
	
//  if문으로 활용시	
//	if ( new_morw_ck.value==2 ||new_morw_ck.value==3 ) { //입력값이 없을때
//		inMORW_no.innerHTML = "";
//		inMORW_ok.innerHTML = "";	
//	}else{
//		inMORW_ok.innerHTML ="선택할수 없는 옵션입니다.";
//		inMORW_no.innerHTML ="";		
//	
//	}
}
